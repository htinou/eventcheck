# OCR local — version 0.3, prototype

Le scan accélère la recherche. Il ne prouve ni l’identité du porteur ni l’authenticité du document et ne confirme jamais une arrivée. La recherche et la confirmation manuelles restent disponibles.

## Parcours

Dans un événement ouvert, choisir « Contrôler une arrivée », puis « Scanner un nom ». Autoriser la caméra arrière, cadrer la zone du nom et du prénom, puis capturer. Une photo JPEG, PNG ou WebP peut aussi être choisie localement. Vérifier les deux champs proposés, les corriger, puis rechercher. Choisir ensuite l’invité et confirmer l’arrivée comme dans le socle. Vérifier les références en cas d’homonymes.

La caméra nécessite HTTPS sur téléphone (localhost est accepté pour les tests ordinateur). En cas de refus, de format illisible ou de lecture trop longue, utiliser la recherche manuelle. Les photos sont limitées à 10 Mo et 32 millions de pixels, puis redimensionnées à 1600 pixels maximum. Une capture vidéo est limitée à une largeur de 1600 pixels. L’annulation, le retour à la recherche, le changement d’écran, la déconnexion et la mise en arrière-plan arrêtent la caméra et le moteur. Les champs conservés pour correction sont effacés en quittant le scan.

## Architecture et limites

Tesseract.js 6.0.1, moteur LSTM local et données françaises 1.0.0. Le worker, les moteurs SIMD/non-SIMD et le modèle sont servis par la même application ; aucun CDN ou prestataire OCR n’est utilisé à l’exécution. Le script `frontend/scripts/ocr-assets.mjs`, exécuté avant build/start, copie ces ressources depuis les dépendances verrouillées. Les ressources techniques peuvent être mises en cache HTTP ; aucun résultat OCR ni capture n’est écrit dans un stockage navigateur. Le cache IndexedDB du moteur est désactivé.

Les captures circulent uniquement en mémoire vers le worker du navigateur. Aucun endpoint d’upload de pièce n’existe. Le texte brut est écarté après extraction ; les seules valeurs retournées à l’interface sont nom et prénom. Le worker est détruit après chaque lecture pour libérer sa mémoire. Les erreurs affichées sont génériques et ne contiennent pas la capture ou le texte OCR. Aucun outil de suivi ou de rapport d’erreur n’est ajouté.

Extraction volontairement prudente : champs nom/prénom explicitement libellés avec deux-points (français/anglais) et première ligne MRZ de passeport de type `P<`. Les numéros de document, dates et autres lignes MRZ ne sont pas retournés. Ce n’est pas un validateur MRZ et aucune vérification cryptographique ni de chiffre de contrôle n’est effectuée. Les CNI à mise en page différente, libellés absents, translittérations, reflets, flous et autres langues peuvent demander une saisie manuelle. Les cas incertains ne sont pas complétés à partir d’une supposition sur le reste du texte.

La première lecture charge le modèle. Une nouvelle lecture recrée le worker : choix conservateur pour la libération des données, pouvant augmenter la latence. Délai d’abandon : 45 secondes. Aucune garantie de lecture en trois secondes sur téléphone n’est annoncée.

## Recette avant pilote réel

Le corpus automatisé contient 30 images synthétiques, dix couples de noms, deux styles de libellés et de petites variations d’inclinaison et de fond. Son rapport contient uniquement les indices, réussites et durées : `ocr-validation/corpus.json`. Les tests navigateur vérifient aussi une correction humaine, deux homonymes, absence d’arrivée automatique, arrêt des pistes vidéo, absence de requête d’envoi de capture et absence de stockage navigateur.

Ce corpus limité ne remplace pas la recette prévue dans le cahier des charges : 30 captures autorisées ou synthétiques représentatives de plusieurs mises en page de pièces, avec au moins 27 extractions correctes, sur de vrais appareils. Tester Safari sur iPhone et Chrome sur Android, caméra réelle, éclairage variable, réseau faible, arrière-plan, refus de permission et mémoire. Mesurer séparément chargement initial et OCR (cible p95 ≤ 3 s hors chargement). Sans cette qualification, le scan reste un prototype ; utiliser le parcours manuel lors d’un événement réel.

Sources techniques : [installation locale](https://github.com/naptha/tesseract.js/blob/master/docs/local-installation.md), [API](https://github.com/naptha/tesseract.js/blob/master/docs/api.md), [modèles](https://github.com/naptha/tessdata). Licences des moteurs présentes dans les ressources servies ; le paquet du modèle déclare MIT.
