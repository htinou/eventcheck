# API de préparation — version 0.2

Toutes les routes utilisent la session et la protection CSRF du socle. Le préfixe est `/api/v1`. Les opérations sur un événement demandent une affectation de superviseur. Les comptes non affectés reçoivent 404.

| Méthode | Route | Usage |
| --- | --- | --- |
| POST | `/events` | Création par un compte autorisé ; trois entrées, créateur superviseur |
| GET | `/events/{id}/preparation` | Métadonnées, révision, équipe et nombre d’invités |
| GET | `/events/{id}/assignable-users` | Comptes existants activés |
| PATCH | `/events/{id}` | Métadonnées du brouillon |
| PUT | `/events/{id}/members` | Remplacement des affectations du brouillon |
| POST | `/events/{id}/imports/preview` | Aperçu du fichier ; aucune écriture |
| POST | `/events/{id}/imports` | Revalidation et remplacement atomique des invités |
| POST | `/events/{id}/open` | Ouverture explicite et gel de la préparation |

Métadonnées JSON : `name`, `startsAtLocal` au format `YYYY-MM-DDTHH:mm`, `timezone` IANA (Europe/Paris par défaut), `purgeAtLocal` facultatif (30 jours après l’événement par défaut), `revision` pour la modification. Les heures inexistantes ou ambiguës des changements d’heure sont refusées. L’API résout le fuseau côté serveur.

Affectations JSON : `revision`, `members: [{userId, role}]`, rôle `AGENT` ou `SUPERVISOR`. Le superviseur effectuant l’opération doit conserver sa propre affectation de superviseur.

Aperçu multipart : `file` et colonnes facultatives `lastColumn`, `firstColumn`, `refColumn` (chaîne vide pour ignorer la référence). Colonnes reconnues automatiquement : nom/prénom/référence et équivalents anglais. Réponse : en-têtes, colonnes, invités, erreurs, avertissements. L’import reprend ces champs, avec `revision` et `acknowledgeWarnings=true` si nécessaire. Le fichier est analysé à nouveau au moment de la confirmation.

Ouverture JSON : `revision`. Au moins un invité et une entrée active sont nécessaires. Un verrou sur l’événement sérialise les mutations ; la révision est augmentée à chaque écriture. Les affectations sont vérifiées à nouveau sous ce verrou. Une révision périmée renvoie 409 `REVISION_CONFLICT`, un événement ouvert ou clôturé 409 `EVENT_FROZEN`. L’import invalide renvoie 400 `IMPORT_NOT_CONFIRMED`, avec le détail d’analyse. Les uploads trop volumineux renvoient 413. Aucun import partiel n’est effectué.

La purge est seulement configurée dans cette version. Aucun traitement périodique de suppression n’est encore livré.
