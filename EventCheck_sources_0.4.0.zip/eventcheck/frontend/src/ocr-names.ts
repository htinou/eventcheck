// Only name fields are returned. Never return or persist document identifiers.
export function extractNames(text:string):{lastName:string;firstName:string} {
  const lines=text.split(/\r?\n/).map(l=>l.trim()).filter(Boolean);
  const clean=(s:string)=>s.replace(/</g,' ').replace(/[^\p{L}\p{M}\s’'\-]/gu,'').replace(/\s+/g,' ').trim().slice(0,100);
  for(const line of lines){
    const mrz=line.toUpperCase().replace(/\s/g,'');
    if(/^P<[A-Z<]{3}[A-Z<]{5,39}$/.test(mrz)&&mrz.length>=30){
      const parts=mrz.slice(5).split('<<');
      if(parts.length>=2)return {lastName:clean(parts[0]),firstName:clean(parts.slice(1).join(' '))};
    }
  }
  let lastName='',firstName='';
  for(let i=0;i<lines.length;i++){
    const line=lines[i];const label=line.normalize('NFD').replace(/\p{M}/gu,'').toUpperCase();
    const last=/^(?:NOM(?: DE FAMILLE)?|SURNAME|LAST NAME)(?:\s*\/\s*(?:SURNAME|NOM))?\s*[:：]\s*/.exec(label);
    const first=/^(?:PRENOMS?|GIVEN NAMES?|FIRST NAME)(?:\s*\/\s*(?:GIVEN NAMES?|PRENOMS?))?\s*[:：]\s*/.exec(label);
    if(last)lastName=clean(line.slice(last[0].length)||lines[i+1]||'');
    if(first)firstName=clean(line.slice(first[0].length)||lines[i+1]||'');
  }
  return {lastName,firstName};
}
