import {Component,ElementRef,ViewChild,Output,EventEmitter,OnDestroy,signal} from '@angular/core';
import {createWorker,OEM,PSM,Worker} from 'tesseract.js';
import {extractNames} from './ocr-names';
@Component({selector:'event-ocr',standalone:true,template:`
<section class="panel ocr-panel"><div class="eyebrow">PROTOTYPE · À QUALIFIER SUR TÉLÉPHONES</div><h2>Lire un nom, puis vérifier.</h2><p class="muted">Image traitée sur ce téléphone, sans envoi ni conservation. Ce scan ne vérifie pas l’authenticité d’une pièce ni l’identité de son porteur.</p>
<video #video autoplay playsinline muted [hidden]="!camera()" aria-label="Aperçu de la caméra"></video>
@if(camera()){<p class="small-text">Cadrez la zone du nom et du prénom, avec un éclairage uniforme.</p><button class="primary" (click)="capture()" [disabled]="busy()">Capturer et lire</button>}
@if(!busy()&&!result()){<button class="primary" (click)="start()">Utiliser la caméra</button><label class="ocr-file">Ou choisir une photo sur ce téléphone<input type="file" accept="image/jpeg,image/png,image/webp" capture="environment" (change)="upload($event)"></label>}
@if(busy()){<p role="status">{{status()}}</p><button class="text-btn" (click)="cancel()">Annuler la lecture</button>}
@if(message()){<p class="homonym" role="status">{{message()}}</p>}
@if(result()){<form (submit)="search($event)"><div class="prep-fields"><label>Nom lu<input maxlength="100" [value]="lastName" (input)="lastName=value($event)"></label><label>Prénom lu<input maxlength="100" [value]="firstName" (input)="firstName=value($event)"></label></div><p class="muted">Vérifiez et corrigez les champs. Aucune arrivée n’est confirmée par le scan.</p><button class="primary" [disabled]="!lastName.trim()&&!firstName.trim()">Rechercher ces noms →</button><button type="button" class="text-btn" (click)="reset()">Reprendre</button></form>}
<button class="text-btn" (click)="manual()">Rechercher par nom sans scan →</button></section>
`})
export class OcrComponent implements OnDestroy {
 @ViewChild('video',{static:true}) video!:ElementRef<HTMLVideoElement>;
 @Output() names=new EventEmitter<string>();@Output() dismissed=new EventEmitter<void>();
 camera=signal(false);busy=signal(false);result=signal(false);message=signal('');status=signal('Préparation du moteur local…');lastName='';firstName='';
 private canvas:HTMLCanvasElement|null=null;private stream:MediaStream|null=null;private worker:Worker|null=null;private generation=0;private destroyed=false;
 constructor(){document.addEventListener('visibilitychange',this.visibility);window.addEventListener('pagehide',this.hide);}
 value(e:Event){return (e.target as HTMLInputElement).value;}
 async start(){this.stopCamera();this.message.set('');const generation=++this.generation;
   try{if(!window.isSecureContext||!navigator.mediaDevices?.getUserMedia)throw new Error();const stream=await navigator.mediaDevices.getUserMedia({audio:false,video:{facingMode:{ideal:'environment'},width:{ideal:1600}}});if(generation!==this.generation||this.destroyed){stream.getTracks().forEach(t=>t.stop());return;}this.stream=stream;this.camera.set(true);this.video.nativeElement.srcObject=stream;await this.video.nativeElement.play();}
   catch{this.stopCamera();this.message.set('Caméra indisponible ou accès refusé. Utilisez une photo locale ou la recherche manuelle. Sur téléphone, un accès HTTPS est nécessaire.');}
 }
 capture(){const video=this.video.nativeElement;if(!video.videoWidth)return;const canvas=document.createElement('canvas');const ratio=Math.min(1,1600/video.videoWidth);canvas.width=Math.round(video.videoWidth*ratio);canvas.height=Math.round(video.videoHeight*ratio);canvas.getContext('2d')!.drawImage(video,0,0,canvas.width,canvas.height);this.stopCamera();void this.read(canvas);}
 async upload(e:Event){const input=e.target as HTMLInputElement;const file=input.files?.[0];input.value='';if(!file)return;this.stopCamera();if(file.size>10*1024*1024||!['image/jpeg','image/png','image/webp'].includes(file.type)){this.message.set('Choisissez une image JPEG, PNG ou WebP de 10 Mo maximum.');return;}
   const generation=++this.generation;let bitmap:ImageBitmap|null=null;
   try{bitmap=await createImageBitmap(file);if(generation!==this.generation||this.destroyed)return;if(bitmap.width*bitmap.height>32_000_000)throw new Error();const ratio=Math.min(1,1600/Math.max(bitmap.width,bitmap.height));const canvas=document.createElement('canvas');canvas.width=Math.round(bitmap.width*ratio);canvas.height=Math.round(bitmap.height*ratio);canvas.getContext('2d')!.drawImage(bitmap,0,0,canvas.width,canvas.height);await this.read(canvas);}catch{this.message.set('Cette image ne peut pas être lue. Reprenez une photo ou recherchez manuellement.');}finally{bitmap?.close();}
 }
 private async read(canvas:HTMLCanvasElement){const generation=++this.generation;this.canvas=canvas;this.busy.set(true);this.message.set('');this.status.set('Chargement du moteur local ; la première lecture peut prendre quelques secondes…');let timer:ReturnType<typeof setTimeout>|undefined;
   try{timer=setTimeout(()=>{if(generation===this.generation){this.cancel();this.message.set('Lecture trop longue. Reprenez une photo plus nette ou recherchez manuellement.');}},45000);
     const worker=await createWorker('fra',OEM.LSTM_ONLY,{workerPath:'/ocr/worker.min.js',corePath:'/ocr',langPath:'/ocr',workerBlobURL:false,cacheMethod:'none',logger:()=>{},errorHandler:()=>{}});
     if(generation!==this.generation||this.destroyed){await worker.terminate();return;}this.worker=worker;this.status.set('Lecture sur ce téléphone…');await worker.setParameters({tessedit_pageseg_mode:PSM.SPARSE_TEXT});
     const response=await worker.recognize(canvas,{}, {text:true});if(generation!==this.generation||this.destroyed)return;const names=extractNames(response.data.text);response.data.text='';this.lastName=names.lastName;this.firstName=names.firstName;this.result.set(true);if(!this.lastName||!this.firstName)this.message.set('Le nom ou le prénom n’a pas été identifié. Renseignez les champs ou utilisez la recherche manuelle.');
   }catch{if(generation===this.generation&&!this.destroyed)this.message.set('La lecture locale a échoué. Reprenez une photo ou recherchez manuellement.');}
   finally{clearTimeout(timer);canvas.width=0;canvas.height=0;if(this.canvas===canvas)this.canvas=null;if(generation===this.generation){this.busy.set(false);await this.terminate();}}
 }
 private stopCamera(){this.stream?.getTracks().forEach(t=>t.stop());this.stream=null;this.video?.nativeElement&&(this.video.nativeElement.srcObject=null);this.camera.set(false);}
 private async terminate(){const worker=this.worker;this.worker=null;if(worker)try{await worker.terminate();}catch{}}
 cancel(){if(this.canvas){this.canvas.width=0;this.canvas.height=0;this.canvas=null;}this.generation++;this.busy.set(false);this.stopCamera();void this.terminate();}
 reset(){this.cancel();this.result.set(false);this.lastName='';this.firstName='';this.message.set('');}
 search(e:Event){e.preventDefault();const query=[this.firstName.trim(),this.lastName.trim()].filter(Boolean).join(' ');this.reset();this.names.emit(query);}
 manual(){this.reset();this.dismissed.emit();}
 private visibility=()=>{if(document.hidden)this.cancel();};private hide=()=>this.cancel();
 ngOnDestroy(){this.destroyed=true;this.reset();document.removeEventListener('visibilitychange',this.visibility);window.removeEventListener('pagehide',this.hide);}
}
