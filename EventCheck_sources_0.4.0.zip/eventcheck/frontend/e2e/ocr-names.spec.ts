import {test,expect} from '@playwright/test';
import {extractNames} from '../src/ocr-names';
test('extraction prudente, noms composés et MRZ sans autres données',()=>{
 expect(extractNames('Nom: Le Goff\nPrénom: Anne-Marie\nDate de naissance: 1990-01-01')).toEqual({lastName:'Le Goff',firstName:'Anne-Marie'});
 expect(extractNames('P<FRALE<GOFF<<ANNE<MARIE<<<<<<<<<<<<<<<<<<<<\n1234567890FRA9001012F3001010<<<<<<<<<<<<<<02')).toEqual({lastName:'LE GOFF',firstName:'ANNE MARIE'});
 expect(extractNames('DOCUMENT\n19900101\n123456789')).toEqual({lastName:'',firstName:''});
});
