package fr.eventcheck;

import java.security.Principal;
import java.time.*;
import java.util.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/v1")
class PreparationController {
    private final JdbcTemplate db; private final EventService events;private final GuestImport importer;private final TransactionTemplate tx;
    PreparationController(JdbcTemplate db,EventService events,GuestImport importer,PlatformTransactionManager manager){this.db=db;this.events=events;this.importer=importer;this.tx=new TransactionTemplate(manager);}
    private Instant instant(Object value){if(value instanceof java.sql.Timestamp t)return t.toInstant();if(value instanceof OffsetDateTime t)return t.toInstant();throw new IllegalStateException("Type de date non pris en charge.");}
    record Metadata(String name,String startsAtLocal,String timezone,String purgeAtLocal,Long revision) {}
    record Member(UUID userId,String role) {}
    record Membership(Long revision,List<Member> members) {}
    record Revision(Long revision) {}
    private void supervisor(UUID id,Principal p){if(!"SUPERVISOR".equals(events.member(id,p.getName()).get("role")))throw new ApiProblem(403,"FORBIDDEN","Cette action est réservée au superviseur.");}
    private void lock(UUID id,Long revision,Principal p){Map<String,Object> e=db.queryForMap("SELECT status,revision FROM events WHERE id=? FOR UPDATE",id);supervisor(id,p);if(!"DRAFT".equals(e.get("status")))throw new ApiProblem(409,"EVENT_FROZEN","La préparation est figée après l’ouverture.");if(revision==null||((Number)e.get("revision")).longValue()!=revision)throw new ApiProblem(409,"REVISION_CONFLICT","La préparation a changé. Actualisez avant de continuer.");}
    private void bump(UUID id){db.update("UPDATE events SET revision=revision+1 WHERE id=?",id);}
    private Object[] metadata(Metadata m){
        try {
            String name=m.name()==null?"":m.name().trim();if(name.isBlank()||name.length()>150)throw new IllegalArgumentException();
            ZoneId zone=ZoneId.of(m.timezone()==null?"Europe/Paris":m.timezone());LocalDateTime local=LocalDateTime.parse(m.startsAtLocal());
            if(zone.getRules().getValidOffsets(local).size()!=1)throw new IllegalArgumentException();
            OffsetDateTime start=local.atZone(zone).toOffsetDateTime();LocalDateTime purge=m.purgeAtLocal()==null||m.purgeAtLocal().isBlank()?local.plusDays(30):LocalDateTime.parse(m.purgeAtLocal());
            if(zone.getRules().getValidOffsets(purge).size()!=1||!purge.isAfter(local))throw new IllegalArgumentException();
            return new Object[]{name,start,zone.getId(),purge.atZone(zone).toOffsetDateTime()};
        }catch(Exception e){throw new ApiProblem(400,"INVALID_METADATA","Renseignez un nom, une date et un fuseau valides ; la conservation doit se terminer après l’événement. Évitez les heures ambiguës du changement d’heure.");}
    }
    @PostMapping("/events") Map<String,Object> create(@RequestBody Metadata request,Principal p){
        Map<String,Object> me=events.me(p.getName());if(!Boolean.TRUE.equals(me.get("canCreateEvents")))throw new ApiProblem(403,"FORBIDDEN","Votre compte ne peut pas créer d’événement.");Object[] m=metadata(request);UUID id=UUID.randomUUID();
        tx.executeWithoutResult(s->{db.update("INSERT INTO events(id,name,starts_at,timezone,purge_at) VALUES (?,?,?,?,?)",id,m[0],m[1],m[2],m[3]);db.update("INSERT INTO event_members(event_id,user_id,role) VALUES (?,?,'SUPERVISOR')",id,UUID.fromString(me.get("id").toString()));for(String label:List.of("Entrée A","Entrée B","Entrée C"))db.update("INSERT INTO entrances(id,event_id,label) VALUES (?,?,?)",UUID.randomUUID(),id,label);});return detail(id,p);
    }
    @GetMapping("/events/{id}/preparation") Map<String,Object> detail(@PathVariable UUID id,Principal p){supervisor(id,p);Map<String,Object> row=db.queryForMap("SELECT * FROM events WHERE id=?",id);ZoneId zone=ZoneId.of(row.get("timezone").toString());Map<String,Object> result=new LinkedHashMap<>(events.event(id));result.put("revision",row.get("revision"));result.put("startsAtLocal",instant(row.get("starts_at")).atZone(zone).toLocalDateTime().toString());result.put("purgeAtLocal",instant(row.get("purge_at")).atZone(zone).toLocalDateTime().toString());result.put("members",db.queryForList("SELECT user_id AS \"userId\",role FROM event_members WHERE event_id=?",id));result.put("total",db.queryForObject("SELECT count(*) FROM guests WHERE event_id=?",Integer.class,id));return result;}
    @GetMapping("/events/{id}/assignable-users") List<Map<String,Object>> users(@PathVariable UUID id,Principal p){supervisor(id,p);return db.queryForList("SELECT id,display_name AS \"displayName\",login FROM users WHERE enabled=true ORDER BY display_name");}
    @PatchMapping("/events/{id}") Map<String,Object> edit(@PathVariable UUID id,@RequestBody Metadata request,Principal p){supervisor(id,p);Object[] m=metadata(request);tx.executeWithoutResult(s->{lock(id,request.revision(),p);db.update("UPDATE events SET name=?,starts_at=?,timezone=?,purge_at=?,revision=revision+1 WHERE id=?",m[0],m[1],m[2],m[3],id);});return detail(id,p);}
    @PutMapping("/events/{id}/members") Map<String,Object> members(@PathVariable UUID id,@RequestBody Membership request,Principal p){supervisor(id,p);UUID self=UUID.fromString(events.me(p.getName()).get("id").toString());if(request.members()==null||request.members().isEmpty()||request.members().size()>100||request.members().stream().noneMatch(m->self.equals(m.userId())&&"SUPERVISOR".equals(m.role())))throw new ApiProblem(400,"INVALID_MEMBERS","Vous devez conserver votre affectation de superviseur.");Set<UUID> ids=new HashSet<>();for(Member m:request.members())if(m.userId()==null||!ids.add(m.userId())||!List.of("AGENT","SUPERVISOR").contains(Objects.toString(m.role(),""))||!Boolean.TRUE.equals(db.queryForObject("SELECT EXISTS(SELECT 1 FROM users WHERE id=? AND enabled=true)",Boolean.class,m.userId())))throw new ApiProblem(400,"INVALID_MEMBERS","Vérifiez les comptes et leurs rôles.");tx.executeWithoutResult(s->{lock(id,request.revision(),p);db.update("DELETE FROM event_members WHERE event_id=?",id);for(Member m:request.members())db.update("INSERT INTO event_members(event_id,user_id,role) VALUES (?,?,?)",id,m.userId(),m.role());bump(id);});return detail(id,p);}
    @PostMapping("/events/{id}/imports/preview") GuestImport.Preview preview(@PathVariable UUID id,@RequestParam MultipartFile file,@RequestParam(required=false) String lastColumn,@RequestParam(required=false) String firstColumn,@RequestParam(required=false) String refColumn,Principal p){supervisor(id,p);if(!"DRAFT".equals(events.event(id).get("status")))throw new ApiProblem(409,"EVENT_FROZEN","La liste est figée après l’ouverture.");return importer.parse(file,lastColumn,firstColumn,refColumn);}
    @PostMapping("/events/{id}/imports") Map<String,Object> apply(@PathVariable UUID id,@RequestParam MultipartFile file,@RequestParam Long revision,@RequestParam(defaultValue="false") boolean acknowledgeWarnings,@RequestParam(required=false) String lastColumn,@RequestParam(required=false) String firstColumn,@RequestParam(required=false) String refColumn,Principal p){supervisor(id,p);GuestImport.Preview preview=importer.parse(file,lastColumn,firstColumn,refColumn);if(!preview.errors().isEmpty()||!preview.warnings().isEmpty()&&!acknowledgeWarnings)throw new ApiProblem(400,"IMPORT_NOT_CONFIRMED","Corrigez les erreurs et confirmez les homonymes avant d’importer.",preview);tx.executeWithoutResult(s->{lock(id,revision,p);db.update("DELETE FROM guests WHERE event_id=?",id);for(GuestImport.Guest g:preview.guests())db.update("INSERT INTO guests(id,event_id,last_name,first_name,external_ref,last_name_search,first_name_search) VALUES (?,?,?,?,?,?,?)",UUID.randomUUID(),id,g.lastName(),g.firstName(),g.reference(),EventService.normalize(g.lastName()),EventService.normalize(g.firstName()));bump(id);});return detail(id,p);}
    @PostMapping("/events/{id}/open") Map<String,Object> open(@PathVariable UUID id,@RequestBody Revision request,Principal p){supervisor(id,p);tx.executeWithoutResult(s->{lock(id,request.revision(),p);if(db.queryForObject("SELECT count(*) FROM guests WHERE event_id=?",Integer.class,id)<1||db.queryForObject("SELECT count(*) FROM entrances WHERE event_id=? AND active=true",Integer.class,id)<1)throw new ApiProblem(400,"EVENT_NOT_READY","Ajoutez au moins un invité et une entrée active.");db.update("UPDATE events SET status='OPEN',opened_at=clock_timestamp(),revision=revision+1 WHERE id=?",id);});return detail(id,p);}
}
