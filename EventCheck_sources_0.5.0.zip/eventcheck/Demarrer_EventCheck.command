#!/bin/sh
cd "$(dirname "$0")" || exit 1
unset DB_URL DB_USER DB_PASSWORD DEMO_PASSWORD
export SPRING_PROFILES_ACTIVE=embedded,demo
exec java -jar release/eventcheck.jar
