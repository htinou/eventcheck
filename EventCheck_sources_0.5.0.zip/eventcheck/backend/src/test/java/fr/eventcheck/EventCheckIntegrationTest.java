package fr.eventcheck;

import static org.assertj.core.api.Assertions.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import java.util.*;
import java.util.concurrent.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest(properties={
    "spring.profiles.active=${TEST_PROFILE:embedded}",
    "spring.datasource.url=${TEST_DB_URL:jdbc:h2:mem:eventcheck_test;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;DEFAULT_NULL_ORDERING=HIGH;DB_CLOSE_DELAY=-1;LOCK_TIMEOUT=10000}",
    "spring.datasource.username=${TEST_DB_USER:eventcheck}","spring.datasource.password=${TEST_DB_PASSWORD:test-only}",
    "spring.datasource.hikari.maximum-pool-size=${TEST_DB_POOL_SIZE:8}","server.servlet.session.cookie.secure=false"
})
@AutoConfigureMockMvc
class EventCheckIntegrationTest {
    @Autowired EventService service; @Autowired JdbcTemplate jdbc; @Autowired MockMvc mvc;
    static final UUID EVENT=UUID.fromString("a0000000-0000-4000-8000-000000000001");
    static final UUID OTHER=UUID.fromString("a0000000-0000-4000-8000-000000000002");
    static final UUID GUEST=UUID.fromString("b0000000-0000-4000-8000-000000000001");
    static final UUID SECOND=UUID.fromString("b0000000-0000-4000-8000-000000000002");
    static final UUID ENT=UUID.fromString("c0000000-0000-4000-8000-000000000001");
    static final UUID OTHER_ENT=UUID.fromString("c0000000-0000-4000-8000-000000000002");
    static final UUID AGENT=UUID.fromString("d0000000-0000-4000-8000-000000000001");
    static final UUID SUP=UUID.fromString("d0000000-0000-4000-8000-000000000002");
    static final UUID FOREIGN=UUID.fromString("d0000000-0000-4000-8000-000000000003");
    @BeforeEach void prepare() {
        jdbc.update("DELETE FROM checkins WHERE event_id IN (?,?)",EVENT,OTHER);
        jdbc.update("DELETE FROM guests WHERE event_id IN (?,?)",EVENT,OTHER);
        jdbc.update("DELETE FROM events WHERE id IN (?,?)",EVENT,OTHER);
        jdbc.update("DELETE FROM users WHERE id IN (?,?,?)",AGENT,SUP,FOREIGN);
        String hash=new BCryptPasswordEncoder(4).encode("Only-a-test-password");
        jdbc.update("INSERT INTO users(id,login,password_hash,display_name) VALUES (?,?,?,?),(?,?,?,?),(?,?,?,?)",AGENT,"test.agent",hash,"Agent de test",SUP,"test.supervisor",hash,"Superviseur de test",FOREIGN,"test.other",hash,"Autre événement");
        for(UUID e:List.of(EVENT,OTHER))jdbc.update("INSERT INTO events(id,name,starts_at,status,opened_at,purge_at) VALUES (?, 'Test',now(),'OPEN',now(),now()+interval '30' day)",e);
        jdbc.update("INSERT INTO entrances(id,event_id,label) VALUES (?,?,'Entrée A'),(?,?,'Entrée A')",ENT,EVENT,OTHER_ENT,OTHER);
        jdbc.update("INSERT INTO event_members(event_id,user_id,role) VALUES (?,?,'AGENT'),(?,?,'SUPERVISOR'),(?,?,'AGENT')",EVENT,AGENT,EVENT,SUP,OTHER,FOREIGN);
        jdbc.update("INSERT INTO guests(id,event_id,last_name,first_name,last_name_search,first_name_search,external_ref) VALUES (?,?,'Martin','Sophie','martin','sophie','INV-001'),(?,?,'Martin','Sophie','martin','sophie','INV-002')",GUEST,EVENT,SECOND,EVENT);
    }
    @Test void atomicArrivalAndReplayPreserveTime() {
        UUID request=UUID.randomUUID();var first=service.checkin(EVENT,GUEST,ENT,request,"test.agent");
        var second=service.checkin(EVENT,GUEST,ENT,request,"test.agent");
        assertThat(first.created()).isTrue();assertThat(second.created()).isFalse();
        assertThat(second.checkin().get("checkinId")).isEqualTo(first.checkin().get("checkinId"));
        assertThat(second.checkin().get("arrivedAt")).isEqualTo(first.checkin().get("arrivedAt"));
        assertThat(jdbc.queryForObject("SELECT count(*) FROM checkins WHERE event_id=?",Integer.class,EVENT)).isEqualTo(1);
    }
    @Test void secondAttemptReturnsExistingArrival() {
        service.checkin(EVENT,GUEST,ENT,UUID.randomUUID(),"test.agent");
        assertThatThrownBy(()->service.checkin(EVENT,GUEST,ENT,UUID.randomUUID(),"test.supervisor"))
            .isInstanceOfSatisfying(ApiProblem.class,p->assertThat(p.code).isEqualTo("ALREADY_CHECKED_IN"));
    }
    @Test void keyCannotBeReusedForAnotherGuestOrAgent() {
        UUID key=UUID.randomUUID();service.checkin(EVENT,GUEST,ENT,key,"test.agent");
        for(Runnable mutation:List.<Runnable>of(()->service.checkin(EVENT,SECOND,ENT,key,"test.agent"),()->service.checkin(EVENT,GUEST,ENT,key,"test.supervisor")))
            assertThatThrownBy(mutation::run).isInstanceOfSatisfying(ApiProblem.class,p->assertThat(p.code).isEqualTo("IDEMPOTENCY_KEY_REUSED"));
    }
    @Test void crossEventEntranceAndUnassignedUserAreRejected() {
        assertThatThrownBy(()->service.checkin(EVENT,GUEST,OTHER_ENT,UUID.randomUUID(),"test.agent")).isInstanceOfSatisfying(ApiProblem.class,p->assertThat(p.status).isEqualTo(404));
        assertThatThrownBy(()->service.snapshot(EVENT,"test.other")).isInstanceOfSatisfying(ApiProblem.class,p->assertThat(p.status).isEqualTo(404));
        assertThat(jdbc.queryForObject("SELECT count(*) FROM checkins WHERE event_id=?",Integer.class,EVENT)).isZero();
    }
    @Test void normalizedSearchAndHomonymsStayDistinct() {
        assertThat(EventService.normalize("  Élodie  Anne-Marie  ")).isEqualTo("elodie anne marie");
        var snapshot=service.snapshot(EVENT,"test.agent");assertThat((List<?>)snapshot.get("guests")).hasSize(2);
        assertThat(snapshot.get("present")).isEqualTo(0L);assertThat(snapshot.get("expected")).isEqualTo(2L);
    }
    @Test void agentCannotCloseAndSupervisorCan() {
        assertThatThrownBy(()->service.close(EVENT,"test.agent")).isInstanceOfSatisfying(ApiProblem.class,p->assertThat(p.status).isEqualTo(403));
        service.close(EVENT,"test.supervisor");
        assertThatThrownBy(()->service.checkin(EVENT,GUEST,ENT,UUID.randomUUID(),"test.agent")).isInstanceOfSatisfying(ApiProblem.class,p->assertThat(p.code).isEqualTo("EVENT_NOT_OPEN"));
    }
    @Test void replayStillWorksAfterClosure() {
        UUID key=UUID.randomUUID();var first=service.checkin(EVENT,GUEST,ENT,key,"test.agent");service.close(EVENT,"test.supervisor");
        assertThat(service.checkin(EVENT,GUEST,ENT,key,"test.agent").checkin().get("arrivedAt")).isEqualTo(first.checkin().get("arrivedAt"));
    }
    @Test void unavailableOrUnauthenticatedEventDoesNotLeakData() throws Exception {
        mvc.perform(get("/api/v1/events/"+EVENT+"/snapshot")).andExpect(status().isUnauthorized());
        mvc.perform(get("/api/v1/events/"+EVENT+"/snapshot").with(user("test.other"))).andExpect(status().isNotFound());
        mvc.perform(get("/api/v1/events").with(user("test.agent"))).andExpect(jsonPath("$.length()").value(1));
    }
    @Test void csrfRequiredAndRoleCheckedOnApi() throws Exception {
        mvc.perform(post("/api/v1/events/"+EVENT+"/close").with(user("test.supervisor"))).andExpect(status().isForbidden());
        mvc.perform(post("/api/v1/events/"+EVENT+"/close").with(user("test.agent")).with(csrf())).andExpect(status().isForbidden());
    }
    @Test void loginRotatesSessionAndLogoutClearsIdentity() throws Exception {
        var session=new MockHttpSession();String original=session.getId();
        mvc.perform(post("/api/v1/auth/login").session(session).with(csrf()).contentType("application/json").content("{\"login\":\"test.agent\",\"password\":\"Only-a-test-password\"}"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.login").value("test.agent"));
        assertThat(session.getId()).isNotEqualTo(original);
        mvc.perform(get("/api/v1/me").session(session)).andExpect(status().isOk());
        mvc.perform(post("/api/v1/auth/logout").session(session).with(csrf())).andExpect(status().isOk());
        mvc.perform(get("/api/v1/me")).andExpect(status().isUnauthorized());
    }
    @Test void disabledAccountCannotAuthenticate() throws Exception {
        jdbc.update("UPDATE users SET enabled=false WHERE id=?",AGENT);
        mvc.perform(post("/api/v1/auth/login").with(csrf()).contentType("application/json").content("{\"login\":\"test.agent\",\"password\":\"Only-a-test-password\"}"))
            .andExpect(status().isUnauthorized()).andExpect(jsonPath("$.code").value("INVALID_CREDENTIALS"));
    }
    @Test void databaseItselfRejectsDuplicate() {
        service.checkin(EVENT,GUEST,ENT,UUID.randomUUID(),"test.agent");
        assertThatThrownBy(()->jdbc.update("INSERT INTO checkins(id,event_id,guest_id,agent_id,entrance_id,request_id) VALUES (?,?,?,?,?,?)",UUID.randomUUID(),EVENT,GUEST,AGENT,ENT,UUID.randomUUID()))
            .isInstanceOf(org.springframework.dao.DataIntegrityViolationException.class);
    }
    @Test void allPresentDoesNotCloseAutomatically() {
        service.checkin(EVENT,GUEST,ENT,UUID.randomUUID(),"test.agent");service.checkin(EVENT,SECOND,ENT,UUID.randomUUID(),"test.agent");
        assertThat(service.snapshot(EVENT,"test.supervisor").get("expected")).isEqualTo(0L);
        assertThat(jdbc.queryForObject("SELECT status FROM events WHERE id=?",String.class,EVENT)).isEqualTo("OPEN");
    }
    @Test
    void threeConcurrentAttemptsAcceptOnlyOneAcross100Runs() throws Exception {
        try(WorkerPool pool=new WorkerPool()) {
            for(int i=0;i<100;i++) {
                jdbc.update("DELETE FROM checkins WHERE event_id=?",EVENT);
                CountDownLatch start=new CountDownLatch(1);List<Future<String>> futures=new ArrayList<>();
                for(int j=0;j<3;j++) futures.add(pool.executor.submit(()->{start.await();try{return service.checkin(EVENT,GUEST,ENT,UUID.randomUUID(),"test.agent").created()?"CREATED":"REPLAY";}catch(ApiProblem p){return p.code;}}));
                start.countDown();List<String> outcomes=new ArrayList<>();for(var f:futures)outcomes.add(f.get(10,TimeUnit.SECONDS));
                assertThat(outcomes).containsExactlyInAnyOrder("CREATED","ALREADY_CHECKED_IN","ALREADY_CHECKED_IN");
                assertThat(jdbc.queryForObject("SELECT count(*) FROM checkins WHERE event_id=?",Integer.class,EVENT)).isEqualTo(1);
            }
        }
    }
    @Test
    void simultaneousRetryKeepsOriginalCheckin() throws Exception {
        UUID key=UUID.randomUUID();CountDownLatch start=new CountDownLatch(1);
        try(WorkerPool pool=new WorkerPool()) {
            List<Future<EventService.CheckinResult>> futures=new ArrayList<>();
            for(int j=0;j<3;j++)futures.add(pool.executor.submit(()->{start.await();return service.checkin(EVENT,GUEST,ENT,key,"test.agent");}));
            start.countDown();var results=new ArrayList<EventService.CheckinResult>();for(var f:futures)results.add(f.get(10,TimeUnit.SECONDS));
            assertThat(results.stream().filter(EventService.CheckinResult::created).count()).isEqualTo(1);
            assertThat(results.stream().map(r->r.checkin().get("checkinId")).distinct().count()).isEqualTo(1);
        }
    }
    @Test @EnabledIfEnvironmentVariable(named="PG_NATIVE",matches="true")
    void closureWaitsForAlreadyStartedValidationAndRejectsFollowingOne() throws Exception {
        try(var connection=jdbc.getDataSource().getConnection();WorkerPool pool=new WorkerPool()) {
            connection.setAutoCommit(false);
            try(var statement=connection.prepareStatement("SELECT status FROM events WHERE id=? FOR SHARE")) {statement.setObject(1,EVENT);statement.executeQuery().close();}
            var closing=pool.executor.submit(()->service.close(EVENT,"test.supervisor"));
            // Wait for the closing transaction to block on this event, rather than relying on a sleep.
            long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(5);boolean blocked=false;
            while(System.nanoTime()<deadline){blocked=Boolean.TRUE.equals(jdbc.queryForObject("SELECT EXISTS(SELECT 1 FROM pg_stat_activity WHERE datname=current_database() AND wait_event_type='Lock' AND query LIKE 'SELECT status FROM events%FOR UPDATE%')",Boolean.class));if(blocked)break;Thread.onSpinWait();}
            assertThat(blocked).isTrue();assertThat(closing.isDone()).isFalse();
            try(var statement=connection.prepareStatement("INSERT INTO checkins(id,event_id,guest_id,agent_id,entrance_id,request_id) VALUES (?,?,?,?,?,?)")){
                UUID[] values={UUID.randomUUID(),EVENT,GUEST,AGENT,ENT,UUID.randomUUID()};for(int n=0;n<6;n++)statement.setObject(n+1,values[n]);statement.executeUpdate();
            }
            connection.commit();assertThat(closing.get(10,TimeUnit.SECONDS).get("status")).isEqualTo("CLOSED");
            assertThatThrownBy(()->service.checkin(EVENT,SECOND,ENT,UUID.randomUUID(),"test.agent")).isInstanceOfSatisfying(ApiProblem.class,p->assertThat(p.code).isEqualTo("EVENT_NOT_OPEN"));
        }
    }
    @Test void embeddedClosureWaitsForArrivalTransaction() throws Exception {
        try(var probe=jdbc.getDataSource().getConnection()){Assumptions.assumeTrue("H2".equals(probe.getMetaData().getDatabaseProductName()));}
        try(var connection=jdbc.getDataSource().getConnection();WorkerPool pool=new WorkerPool()) {
            connection.setAutoCommit(false);
            try(var statement=connection.prepareStatement("SELECT status FROM events WHERE id=? FOR UPDATE")){statement.setObject(1,EVENT);statement.executeQuery().close();}
            CountDownLatch entered=new CountDownLatch(1);var closing=pool.executor.submit(()->{entered.countDown();return service.close(EVENT,"test.supervisor");});
            assertThat(entered.await(5,TimeUnit.SECONDS)).isTrue();
            assertThatThrownBy(()->closing.get(150,TimeUnit.MILLISECONDS)).isInstanceOf(TimeoutException.class);
            try(var statement=connection.prepareStatement("INSERT INTO checkins(id,event_id,guest_id,agent_id,entrance_id,request_id) VALUES (?,?,?,?,?,?)")){UUID[] values={UUID.randomUUID(),EVENT,GUEST,AGENT,ENT,UUID.randomUUID()};for(int i=0;i<6;i++)statement.setObject(i+1,values[i]);statement.executeUpdate();}
            connection.commit();assertThat(closing.get(10,TimeUnit.SECONDS).get("status")).isEqualTo("CLOSED");
            assertThatThrownBy(()->service.checkin(EVENT,SECOND,ENT,UUID.randomUUID(),"test.agent")).isInstanceOfSatisfying(ApiProblem.class,p->assertThat(p.code).isEqualTo("EVENT_NOT_OPEN"));
            assertThat(jdbc.queryForObject("SELECT count(*) FROM checkins WHERE event_id=?",Integer.class,EVENT)).isEqualTo(1);
        }
    }
    static class WorkerPool implements AutoCloseable {
        final ExecutorService executor=Executors.newFixedThreadPool(3);
        public void close(){executor.shutdownNow();}
    }
}
