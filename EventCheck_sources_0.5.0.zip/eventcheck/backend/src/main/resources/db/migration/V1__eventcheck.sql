CREATE TABLE users (
  id uuid PRIMARY KEY,
  login varchar(254) NOT NULL UNIQUE,
  password_hash text NOT NULL,
  display_name varchar(150) NOT NULL,
  can_create_events boolean NOT NULL DEFAULT false,
  enabled boolean NOT NULL DEFAULT true
);

CREATE TABLE events (
  id uuid PRIMARY KEY,
  name varchar(150) NOT NULL,
  starts_at timestamptz NOT NULL,
  timezone varchar(100) NOT NULL DEFAULT 'Europe/Paris',
  status varchar(10) NOT NULL DEFAULT 'DRAFT'
    CHECK (status IN ('DRAFT','OPEN','CLOSED')),
  revision bigint NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  opened_at timestamptz,
  closed_at timestamptz,
  purge_at timestamptz NOT NULL,
  CHECK (
    (status = 'DRAFT' AND opened_at IS NULL AND closed_at IS NULL) OR
    (status = 'OPEN' AND opened_at IS NOT NULL AND closed_at IS NULL) OR
    (status = 'CLOSED' AND opened_at IS NOT NULL AND closed_at IS NOT NULL)
  )
);

CREATE TABLE entrances (
  id uuid PRIMARY KEY,
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  label varchar(50) NOT NULL,
  active boolean NOT NULL DEFAULT true,
  UNIQUE (event_id, id),
  UNIQUE (event_id, label)
);

CREATE TABLE event_members (
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id),
  role varchar(20) NOT NULL CHECK (role IN ('AGENT','SUPERVISOR')),
  PRIMARY KEY (event_id, user_id)
);

CREATE TABLE guests (
  id uuid PRIMARY KEY,
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  external_ref varchar(100),
  last_name varchar(100) NOT NULL CHECK (length(trim(last_name)) > 0),
  first_name varchar(100) NOT NULL CHECK (length(trim(first_name)) > 0),
  last_name_search varchar(200) NOT NULL,
  first_name_search varchar(200) NOT NULL,
  UNIQUE (event_id, id),
  UNIQUE (event_id, external_ref)
);

CREATE TABLE checkins (
  id uuid PRIMARY KEY,
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  guest_id uuid NOT NULL,
  agent_id uuid NOT NULL,
  entrance_id uuid NOT NULL,
  request_id uuid NOT NULL UNIQUE,
  arrived_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  UNIQUE (event_id, guest_id),
  FOREIGN KEY (event_id, guest_id) REFERENCES guests(event_id, id),
  FOREIGN KEY (event_id, agent_id) REFERENCES event_members(event_id, user_id),
  FOREIGN KEY (event_id, entrance_id) REFERENCES entrances(event_id, id)
);

CREATE INDEX guests_event_idx ON guests(event_id);
CREATE INDEX checkins_event_time_idx ON checkins(event_id, arrived_at DESC);
