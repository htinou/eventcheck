package fr.eventcheck;

import java.util.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/events")
class EventController {
    private final EventService service;
    EventController(EventService service) { this.service=service; }
    record CheckinRequest(@NotNull UUID guestId,@NotNull UUID entranceId) {}
    @GetMapping List<Map<String,Object>> events(Authentication user) { return service.events(user.getName()); }
    @GetMapping("/{id}/snapshot") Map<String,Object> snapshot(@PathVariable UUID id,Authentication user) { return service.snapshot(id,user.getName()); }
    @PostMapping("/{id}/checkins") ResponseEntity<?> checkin(@PathVariable UUID id,@RequestHeader("Idempotency-Key") UUID request,@Valid @RequestBody CheckinRequest body,Authentication user) {
        var result=service.checkin(id,body.guestId(),body.entranceId(),request,user.getName());
        return ResponseEntity.status(result.created()?201:200).body(result.checkin());
    }
    @PostMapping("/{id}/close") Map<String,Object> close(@PathVariable UUID id,Authentication user) { return service.close(id,user.getName()); }
}
