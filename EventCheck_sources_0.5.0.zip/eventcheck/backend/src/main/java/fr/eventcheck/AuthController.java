package fr.eventcheck;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.session.ChangeSessionIdAuthenticationStrategy;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.security.web.csrf.CsrfAuthenticationStrategy;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
class AuthController {
    record Login(@NotBlank @Size(max=254) String login, @NotBlank @Size(max=128) String password) {}
    record Window(long since,int attempts) {}
    private final AuthenticationManager manager;
    private final SecurityContextRepository repository;
    private final EventService service;
    private final ConcurrentHashMap<String,Window> attempts = new ConcurrentHashMap<>();
    AuthController(AuthenticationManager manager,SecurityContextRepository repository,EventService service) {
        this.manager=manager; this.repository=repository; this.service=service;
    }
    @GetMapping("/auth/csrf") Map<String,String> csrf(CsrfToken token) {
        return Map.of("token",token.getToken(),"headerName",token.getHeaderName());
    }
    @PostMapping("/auth/login") Map<String,Object> login(@Valid @RequestBody Login data,HttpServletRequest req,HttpServletResponse res) {
        long now=Instant.now().getEpochSecond();
        attempts.entrySet().removeIf(e -> now-e.getValue().since()>600);
        var window=attempts.compute(req.getRemoteAddr(),(ip,old) -> old==null||now-old.since()>600 ? new Window(now,1) : new Window(old.since(),old.attempts()+1));
        if(window.attempts()>20) throw new ApiProblem(429,"RATE_LIMITED","Trop de tentatives. Réessayez dans quelques minutes.");
        if(data.password().getBytes(java.nio.charset.StandardCharsets.UTF_8).length>72)
            throw new ApiProblem(401,"INVALID_CREDENTIALS","Identifiant ou mot de passe incorrect.");
        try {
            Authentication auth=manager.authenticate(UsernamePasswordAuthenticationToken.unauthenticated(data.login().trim().toLowerCase(Locale.ROOT),data.password()));
            new ChangeSessionIdAuthenticationStrategy().onAuthentication(auth,req,res);
            new CsrfAuthenticationStrategy(new HttpSessionCsrfTokenRepository()).onAuthentication(auth,req,res);
            var context=SecurityContextHolder.createEmptyContext(); context.setAuthentication(auth);
            SecurityContextHolder.setContext(context); repository.saveContext(context,req,res);
            return service.me(auth.getName());
        } catch(AuthenticationException ignored) {
            throw new ApiProblem(401,"INVALID_CREDENTIALS","Identifiant ou mot de passe incorrect.");
        }
    }
    @GetMapping("/me") Map<String,Object> me(Authentication auth) { return service.me(auth.getName()); }
    @PostMapping("/auth/logout") Map<String,Boolean> logout(HttpServletRequest req) {
        var session=req.getSession(false); if(session!=null) session.invalidate();
        SecurityContextHolder.clearContext(); return Map.of("loggedOut",true);
    }
}
