package fr.eventcheck;

import java.io.*;
import java.nio.*;
import java.nio.charset.*;
import java.util.*;
import java.util.zip.*;
import org.apache.commons.csv.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
class GuestImport {
    record Guest(int line, String lastName, String firstName, String reference) {}
    record Preview(List<String> headers, String lastColumn, String firstColumn, String refColumn,
                   List<Guest> guests, List<String> errors, List<String> warnings) {}
    Preview parse(MultipartFile file, String last, String first, String ref) {
        if(file.isEmpty()||file.getSize()>2*1024*1024) throw new ApiProblem(400,"INVALID_FILE","Choisissez un fichier CSV ou Excel de 2 Mo maximum.");
        List<List<String>> rows=new ArrayList<>(); List<Integer> lines=new ArrayList<>();
        try {
            String filename=Objects.toString(file.getOriginalFilename(),"").toLowerCase(Locale.ROOT);
            if(filename.endsWith(".csv")) {
                String text=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(file.getBytes())).toString().replaceFirst("^\uFEFF","");
                String header=text.lines().findFirst().orElse(""); char delimiter=header.chars().filter(c->c==';').count()>header.chars().filter(c->c==',').count()?';':',';
                try(CSVParser parser=CSVFormat.DEFAULT.builder().setDelimiter(delimiter).setIgnoreEmptyLines(true).get().parse(new StringReader(text))) {
                    for(CSVRecord record:parser) {
                        if(rows.size()>100) throw new ApiProblem(400,"TOO_MANY_GUESTS","La liste est limitée à 100 invités.");
                        if(record.size()>30) throw new ApiProblem(400,"INVALID_FILE","Le fichier contient trop de colonnes (30 maximum).");
                        rows.add(record.toList()); lines.add((int)record.getRecordNumber());
                    }
                }
            } else if(filename.endsWith(".xlsx")) {
                // Bound total expanded content before POI constructs the workbook in memory.
                try(ZipInputStream zip=new ZipInputStream(file.getInputStream())) {
                    long expanded=0;int entries=0;byte[] buffer=new byte[8192];
                    while(zip.getNextEntry()!=null){if(++entries>256)throw new IOException();int read;while((read=zip.read(buffer))!=-1){expanded+=read;if(expanded>16*1024*1024)throw new IOException();}}
                }
                ZipSecureFile.setMaxEntrySize(8*1024*1024); ZipSecureFile.setMaxTextSize(8*1024*1024);
                try(XSSFWorkbook book=new XSSFWorkbook(file.getInputStream())) {
                    if(book.getNumberOfSheets()==0) throw new IOException();
                    Sheet sheet=book.getSheetAt(0); DataFormatter formatter=new DataFormatter(Locale.FRANCE);
                    for(Row row:sheet) {
                        if(row.getLastCellNum()>30) throw new ApiProblem(400,"INVALID_FILE","Le fichier contient trop de colonnes (30 maximum).");
                        List<String> cells=new ArrayList<>();
                        for(int c=0;c<Math.max(0,row.getLastCellNum());c++) {
                            Cell cell=row.getCell(c);
                            if(cell!=null&&cell.getCellType()==CellType.FORMULA) throw new ApiProblem(400,"FORMULA_NOT_ALLOWED","Les formules Excel ne sont pas acceptées. Copiez les valeurs avant l’import.");
                            cells.add(cell==null?"":formatter.formatCellValue(cell));
                        }
                        if(cells.stream().allMatch(String::isBlank))continue;
                        if(rows.size()>100)throw new ApiProblem(400,"TOO_MANY_GUESTS","La liste est limitée à 100 invités.");
                        rows.add(cells);lines.add(row.getRowNum()+1);
                    }
                }
            } else throw new ApiProblem(400,"INVALID_FILE","Formats acceptés : CSV UTF-8 et XLSX.");
        } catch(ApiProblem e){throw e;} catch(Exception e){throw new ApiProblem(400,"INVALID_FILE","Le fichier est illisible. Vérifiez son format et l’encodage UTF-8 du CSV.");}
        if(rows.size()<2)throw new ApiProblem(400,"EMPTY_LIST","Le fichier doit contenir un en-tête et au moins un invité.");
        List<String> headers=rows.get(0).stream().map(String::trim).toList();
        if(headers.stream().anyMatch(String::isBlank)||new HashSet<>(headers).size()!=headers.size())throw new ApiProblem(400,"INVALID_HEADERS","Les en-têtes doivent être renseignés et distincts.");
        last=choose(last,headers,List.of("nom","last name","lastname"));first=choose(first,headers,List.of("prenom","first name","firstname"));ref=choose(ref,headers,List.of("reference","ref","id"));
        List<String> errors=new ArrayList<>(),warnings=new ArrayList<>();List<Guest> guests=new ArrayList<>();Set<String> refs=new HashSet<>(),names=new HashSet<>();
        int li=headers.indexOf(last),fi=headers.indexOf(first),ri=headers.indexOf(ref);
        if(li<0||fi<0||li==fi||ri>=0&&(ri==li||ri==fi))errors.add("Sélectionnez des colonnes distinctes pour le nom, le prénom et la référence.");
        else for(int i=1;i<rows.size();i++) {
            List<String> row=rows.get(i);int line=lines.get(i);String l=value(row,li),f=value(row,fi),reference=ri<0?"":value(row,ri);
            if(row.size()>headers.size())errors.add("Ligne "+line+" : trop de colonnes.");
            if(l.isEmpty()||f.isEmpty()||l.length()>100||f.length()>100||reference.length()>100)errors.add("Ligne "+line+" : nom et prénom obligatoires, 100 caractères maximum par champ.");
            if(!reference.isEmpty()&&!refs.add(reference))errors.add("Ligne "+line+" : référence répétée « "+reference+" ».");
            String identity=EventService.normalize(l)+"|"+EventService.normalize(f);
            if(!names.add(identity))warnings.add("Ligne "+line+" : homonyme « "+f+" "+l+" ». Vérifiez les références.");
            guests.add(new Guest(line,l,f,reference.isEmpty()?null:reference));
        }
        return new Preview(headers,last,first,ref,guests,errors,warnings);
    }
    private String choose(String selected,List<String> headers,List<String> aliases){if(selected!=null)return selected;return headers.stream().filter(h->aliases.contains(EventService.normalize(h))).findFirst().orElse("");}
    private String value(List<String> row,int column){return column<row.size()?row.get(column).trim():"";}
}
