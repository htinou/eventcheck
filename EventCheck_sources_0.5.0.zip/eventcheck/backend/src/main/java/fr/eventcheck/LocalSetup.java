package fr.eventcheck;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermissions;
import java.security.SecureRandom;
import java.util.*;
import java.io.*;

final class LocalSetup {
 static void configure(String[] args) throws IOException {
  String profiles=System.getProperty("spring.profiles.active",System.getenv().getOrDefault("SPRING_PROFILES_ACTIVE",""));
  for(String arg:args)if(arg.startsWith("--spring.profiles.active="))profiles=arg.substring("--spring.profiles.active=".length());
  if(profiles.isBlank()&&System.getenv().getOrDefault("DB_URL","").startsWith("jdbc:postgresql:")){System.setProperty("spring.profiles.active","postgres,demo");return;}
  if(!profiles.isBlank()&&!Arrays.asList(profiles.split(",")).contains("embedded"))return;
  String directory=System.getenv().getOrDefault("EVENTCHECK_DATA_DIR",Path.of(System.getProperty("user.home"),"EventCheck").toString());
  Path data=Path.of(directory).toAbsolutePath().normalize();Files.createDirectories(data);
  Path secrets=data.resolve("acces-local.properties");
  if(!Files.exists(secrets)){
   Properties initial=new Properties();initial.setProperty("database.password",password());initial.setProperty("demo.password",password());
   try(OutputStream out=Files.newOutputStream(secrets,StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE)){initial.store(out,"EventCheck : conserver avec la base. Mot de passe des comptes locaux dans demo.password.");}
   try{Files.setPosixFilePermissions(secrets,PosixFilePermissions.fromString("rw-------"));}catch(UnsupportedOperationException ignored){}
  }
  Properties values=new Properties();try(InputStream in=Files.newInputStream(secrets)){values.load(in);}
  if(values.getProperty("database.password","").length()<16||values.getProperty("demo.password","").length()<16)throw new IOException("Fichier des accès locaux incomplet : "+secrets);
  System.setProperty("eventcheck.data-dir",data.toString().replace('\\','/'));
  System.setProperty("eventcheck.local-db-password",values.getProperty("database.password"));
  System.setProperty("eventcheck.demo-password",values.getProperty("demo.password"));
  System.out.println("EventCheck local : http://localhost:8080 — comptes accueil.a / accueil.b / accueil.c / supervision.");
  System.out.println("Mot de passe initial : valeur demo.password du fichier "+secrets);
  System.out.println("Base persistante : "+data.resolve("eventcheck.mv.db"));
 }
 private static String password(){byte[] bytes=new byte[24];new SecureRandom().nextBytes(bytes);return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);}
}
