package fr.eventcheck;
public final class EmbeddedClock {
    private EmbeddedClock() {}
    public static java.time.OffsetDateTime now(){return java.time.OffsetDateTime.now(java.time.ZoneOffset.UTC);}
}
