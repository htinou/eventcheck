package fr.eventcheck;

import java.time.Instant;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Profile("demo")
class DemoData implements ApplicationRunner {
    private final JdbcTemplate jdbc; private final PasswordEncoder encoder; private final String password;
    DemoData(JdbcTemplate jdbc,PasswordEncoder encoder,@Value("${eventcheck.demo-password}") String password) { this.jdbc=jdbc; this.encoder=encoder; this.password=password; }
    @Override @Transactional public void run(ApplicationArguments args) {
        if(password.length()<16) throw new IllegalStateException("Le profil demo exige DEMO_PASSWORD d’au moins 16 caractères.");
        UUID event=UUID.fromString("10000000-0000-4000-8000-000000000001");
        if(Boolean.TRUE.equals(jdbc.queryForObject("SELECT EXISTS(SELECT 1 FROM events WHERE id=?)",Boolean.class,event))) return;
        String hash=encoder.encode(password);
        jdbc.update("INSERT INTO events(id,name,starts_at,status,opened_at,purge_at) VALUES (?, ?, ?, 'OPEN',clock_timestamp(), ?)",event,"Rencontres EventCheck · Démonstration",java.sql.Timestamp.from(Instant.now()),java.sql.Timestamp.from(Instant.now().plusSeconds(30*86400)));
        String[] logins={"accueil.a","accueil.b","accueil.c","supervision"};
        String[] names={"Agent entrée A","Agent entrée B","Agent entrée C","Superviseur"};
        for(int i=0;i<4;i++) {
            UUID user=UUID.nameUUIDFromBytes(logins[i].getBytes(java.nio.charset.StandardCharsets.UTF_8));
            if(!Boolean.TRUE.equals(jdbc.queryForObject("SELECT EXISTS(SELECT 1 FROM users WHERE login=?)",Boolean.class,logins[i]))) jdbc.update("INSERT INTO users(id,login,password_hash,display_name,can_create_events) VALUES (?,?,?,?,?)",user,logins[i],hash,names[i],i==3);
            UUID actual=jdbc.queryForObject("SELECT id FROM users WHERE login=?",UUID.class,logins[i]);
            jdbc.update("INSERT INTO event_members(event_id,user_id,role) VALUES (?,?,?)",event,actual,i==3?"SUPERVISOR":"AGENT");
            if(i<3) jdbc.update("INSERT INTO entrances(id,event_id,label) VALUES (?,?,?)",UUID.randomUUID(),event,"Entrée "+(char)('A'+i));
        }
        String[][] guests={{"Martin","Sophie"},{"Bernard","Thomas"},{"Petit","Julie"},{"Dubois","Élodie"},{"Ben Ali","Karim"},{"Martin","Sophie"},{"Le Goff","Anne-Marie"},{"Moreau","Lucas"},{"Roy","Camille"},{"Singh","Aarav"}};
        for(int i=0;i<guests.length;i++) jdbc.update("INSERT INTO guests(id,event_id,external_ref,last_name,first_name,last_name_search,first_name_search) VALUES (?,?,?,?,?,?,?)",UUID.randomUUID(),event,String.format("INV-%03d",i+1),guests[i][0],guests[i][1],EventService.normalize(guests[i][0]),EventService.normalize(guests[i][1]));
    }
}
