package fr.eventcheck;

import java.util.Map;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.security.web.context.SecurityContextRepository;

@Configuration
class SecurityConfig {
    @Bean PasswordEncoder passwordEncoder() { return new BCryptPasswordEncoder(12); }
    @Bean SecurityContextRepository contextRepository() { return new HttpSessionSecurityContextRepository(); }
    @Bean UserDetailsService users(JdbcTemplate jdbc) {
        return login -> jdbc.query("SELECT login,password_hash,enabled FROM users WHERE login=?",(rs,n) ->
            User.withUsername(rs.getString("login")).password(rs.getString("password_hash"))
                .roles("USER").disabled(!rs.getBoolean("enabled")).build(),login)
            .stream().findFirst().orElseThrow(() -> new UsernameNotFoundException("Compte indisponible"));
    }
    @Bean AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
    @Bean SecurityFilterChain filterChain(HttpSecurity http, SecurityContextRepository repository, ObjectMapper mapper) throws Exception {
        http.securityContext(context -> context.securityContextRepository(repository))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/v1/auth/csrf","/api/v1/auth/login","/","/index.html","/*.js","/*.css","/favicon.svg").permitAll()
                .anyRequest().authenticated())
            .requestCache(cache -> cache.disable())
            .formLogin(form -> form.disable()).httpBasic(basic -> basic.disable()).logout(logout -> logout.disable())
            .exceptionHandling(errors -> errors
                .authenticationEntryPoint((req,res,ex) -> {
                    res.setStatus(401); res.setContentType("application/json;charset=UTF-8");
                    mapper.writeValue(res.getWriter(),ApiProblem.payload("UNAUTHENTICATED","Connectez-vous pour continuer.",Map.of()));
                })
                .accessDeniedHandler((req,res,ex) -> {
                    res.setStatus(403); res.setContentType("application/json;charset=UTF-8");
                    mapper.writeValue(res.getWriter(),ApiProblem.payload("FORBIDDEN","Demande refusée. Actualisez votre session.",Map.of()));
                }));
        return http.build();
    }
}
