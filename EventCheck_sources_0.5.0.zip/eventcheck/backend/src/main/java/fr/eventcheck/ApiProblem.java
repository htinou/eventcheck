package fr.eventcheck;

import java.util.Map;
import java.util.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MissingRequestHeaderException;

public class ApiProblem extends RuntimeException {
    final int status;
    final String code;
    final Object details;
    ApiProblem(int status, String code, String message) { this(status, code, message, Map.of()); }
    ApiProblem(int status, String code, String message, Object details) {
        super(message); this.status = status; this.code = code; this.details = details;
    }
    static Map<String,Object> payload(String code, String message, Object details) {
        return Map.of("code",code,"message",message,"details",details,"traceId",UUID.randomUUID().toString());
    }
}

@RestControllerAdvice
class ApiProblemHandler {
    @ExceptionHandler(org.springframework.web.multipart.MaxUploadSizeExceededException.class)
    ResponseEntity<?> tooLarge(Exception ignored) {return ResponseEntity.status(413).body(ApiProblem.payload("FILE_TOO_LARGE","Le fichier dépasse la limite de 2 Mo.",Map.of()));}
    @ExceptionHandler(ApiProblem.class)
    ResponseEntity<?> problem(ApiProblem error) {
        return ResponseEntity.status(error.status).body(ApiProblem.payload(error.code,error.getMessage(),error.details));
    }
    @ExceptionHandler({MethodArgumentNotValidException.class, MethodArgumentTypeMismatchException.class, HttpMessageNotReadableException.class, MissingRequestHeaderException.class, org.springframework.web.bind.MissingServletRequestParameterException.class, org.springframework.web.multipart.support.MissingServletRequestPartException.class})
    ResponseEntity<?> invalid(Exception ignored) {
        return ResponseEntity.badRequest().body(ApiProblem.payload("INVALID_REQUEST","Vérifiez les champs de la demande.",Map.of()));
    }
}
