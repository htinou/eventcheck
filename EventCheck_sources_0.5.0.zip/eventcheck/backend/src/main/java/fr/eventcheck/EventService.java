package fr.eventcheck;

import java.text.Normalizer;
import java.util.*;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

@Service
public class EventService {
    private final JdbcTemplate jdbc;
    private final PlatformTransactionManager manager;
    private final boolean embedded;
    public EventService(JdbcTemplate jdbc,PlatformTransactionManager manager,@org.springframework.beans.factory.annotation.Value("${eventcheck.embedded:false}") boolean embedded) { this.jdbc=jdbc; this.manager=manager; this.embedded=embedded; }
    public static String normalize(String value) {
        return Normalizer.normalize(value,Normalizer.Form.NFD).replaceAll("\\p{M}","")
            .toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+"," ").trim().replaceAll("\\s+"," ");
    }
    Map<String,Object> me(String login) {
        return jdbc.query("SELECT id,login,display_name,can_create_events FROM users WHERE login=? AND enabled",(rs,n) -> {
            Map<String,Object> user=new LinkedHashMap<>(); user.put("id",rs.getObject("id")); user.put("login",rs.getString("login"));
            user.put("displayName",rs.getString("display_name")); user.put("canCreateEvents",rs.getBoolean("can_create_events")); return user;
        },login).stream().findFirst().orElseThrow(() -> new ApiProblem(401,"UNAUTHENTICATED","Compte indisponible."));
    }
    Map<String,Object> member(UUID event,String login) {
        return jdbc.query("SELECT u.id,m.role,u.display_name FROM event_members m JOIN users u ON u.id=m.user_id WHERE m.event_id=? AND u.login=? AND u.enabled",(rs,n) ->
            Map.<String,Object>of("id",rs.getObject("id"),"role",rs.getString("role"),"displayName",rs.getString("display_name")),event,login)
            .stream().findFirst().orElseThrow(() -> new ApiProblem(404,"NOT_FOUND","Événement indisponible."));
    }
    List<Map<String,Object>> events(String login) {
        return jdbc.query("SELECT e.id,e.name,e.starts_at,e.timezone,e.status,m.role,(SELECT count(*) FROM guests g WHERE g.event_id=e.id) AS total,(SELECT count(*) FROM checkins c WHERE c.event_id=e.id) AS present FROM events e JOIN event_members m ON m.event_id=e.id JOIN users u ON u.id=m.user_id WHERE u.login=? AND u.enabled ORDER BY e.starts_at",(rs,n) ->
            Map.of("id",rs.getObject("id"),"name",rs.getString("name"),"startsAt",rs.getTimestamp("starts_at").toInstant().toString(),"timezone",rs.getString("timezone"),"status",rs.getString("status"),"role",rs.getString("role"),"total",rs.getLong("total"),"present",rs.getLong("present")),login);
    }
    Map<String,Object> event(UUID id) {
        return jdbc.query("SELECT * FROM events WHERE id=?",(rs,n) -> Map.<String,Object>of(
            "id",rs.getObject("id"),"name",rs.getString("name"),"status",rs.getString("status"),
            "startsAt",rs.getTimestamp("starts_at").toInstant().toString(),"timezone",rs.getString("timezone")),id)
            .stream().findFirst().orElseThrow(() -> new ApiProblem(404,"NOT_FOUND","Événement indisponible."));
    }
    public Map<String,Object> snapshot(UUID id,String login) {
        var tx=new TransactionTemplate(manager); tx.setReadOnly(true); tx.setIsolationLevel(TransactionDefinition.ISOLATION_REPEATABLE_READ);
        return tx.execute(status -> {
            var membership=member(id,login); var event=event(id);
            var entrances=jdbc.query("SELECT id,label,active FROM entrances WHERE event_id=? ORDER BY label",(rs,n) ->
                Map.of("id",rs.getObject("id"),"label",rs.getString("label"),"active",rs.getBoolean("active")),id);
            var guests=jdbc.query("SELECT g.*,c.id AS checkin_id,c.arrived_at,c.entrance_id,en.label AS entrance_label,u.display_name AS agent_name FROM guests g LEFT JOIN checkins c ON c.guest_id=g.id AND c.event_id=g.event_id LEFT JOIN entrances en ON en.id=c.entrance_id LEFT JOIN users u ON u.id=c.agent_id WHERE g.event_id=? ORDER BY g.last_name_search,g.first_name_search,g.id",(rs,n) -> {
                Map<String,Object> row=new LinkedHashMap<>(); row.put("id",rs.getObject("id")); row.put("lastName",rs.getString("last_name")); row.put("firstName",rs.getString("first_name"));
                row.put("reference",rs.getString("external_ref")); row.put("search",rs.getString("last_name_search")+" "+rs.getString("first_name_search"));
                row.put("status",rs.getObject("checkin_id")==null?"EXPECTED":"PRESENT");
                row.put("arrivedAt",rs.getTimestamp("arrived_at")==null?null:rs.getTimestamp("arrived_at").toInstant().toString());
                row.put("entranceId",rs.getObject("entrance_id")); row.put("entranceLabel",rs.getString("entrance_label")); row.put("agentName",rs.getString("agent_name")); return row;
            },id);
            long present=guests.stream().filter(g -> "PRESENT".equals(g.get("status"))).count();
            return Map.<String,Object>of("event",event,"role",membership.get("role"),"entrances",entrances,"guests",guests,
                "total",guests.size(),"present",present,"expected",guests.size()-present,"serverTime",java.time.Instant.now().toString());
        });
    }
    private static final String CHECKIN_SELECT="SELECT c.*,u.display_name AS agent_name,e.label AS entrance_label FROM checkins c JOIN users u ON u.id=c.agent_id JOIN entrances e ON e.id=c.entrance_id ";
    private List<Map<String,Object>> findRequest(UUID request) { return jdbc.query(CHECKIN_SELECT+"WHERE c.request_id=?",(rs,n) -> checkinRow(rs),request); }
    private List<Map<String,Object>> findGuest(UUID event,UUID guest) { return jdbc.query(CHECKIN_SELECT+"WHERE c.event_id=? AND c.guest_id=?",(rs,n) -> checkinRow(rs),event,guest); }
    private Map<String,Object> checkinRow(java.sql.ResultSet rs) throws java.sql.SQLException {
        return Map.of("checkinId",rs.getObject("id"),"eventId",rs.getObject("event_id"),"guestId",rs.getObject("guest_id"),"agentId",rs.getObject("agent_id"),"entranceId",rs.getObject("entrance_id"),"arrivedAt",rs.getTimestamp("arrived_at").toInstant().toString(),"agentName",rs.getString("agent_name"),"entranceLabel",rs.getString("entrance_label"));
    }
    public record CheckinResult(boolean created,Map<String,Object> checkin) {}
    private CheckinResult replay(Map<String,Object> existing,UUID event,UUID guest,UUID entrance,UUID agent) {
        if(!event.equals(existing.get("eventId"))||!guest.equals(existing.get("guestId"))||!entrance.equals(existing.get("entranceId"))||!agent.equals(existing.get("agentId")))
            throw new ApiProblem(409,"IDEMPOTENCY_KEY_REUSED","Cette tentative appartient à un autre contrôle.");
        var result=new LinkedHashMap<>(existing); result.put("replayed",true); return new CheckinResult(false,result);
    }
    public CheckinResult checkin(UUID event,UUID guest,UUID entrance,UUID request,String login) {
        UUID agent=(UUID) member(event,login).get("id");
        var processed=findRequest(request); if(!processed.isEmpty()) return replay(processed.get(0),event,guest,entrance,agent);
        try {
            return new TransactionTemplate(manager).execute(status -> {
                var state=jdbc.queryForObject("SELECT status FROM events WHERE id=? "+(embedded?"FOR UPDATE":"FOR SHARE"),String.class,event);
                if(!"OPEN".equals(state)) throw new ApiProblem(409,"EVENT_NOT_OPEN","L’accueil n’est pas ouvert.");
                if(!Boolean.TRUE.equals(jdbc.queryForObject("SELECT EXISTS(SELECT 1 FROM entrances WHERE id=? AND event_id=? AND active)",Boolean.class,entrance,event)))
                    throw new ApiProblem(404,"NOT_FOUND","Entrée indisponible.");
                if(!Boolean.TRUE.equals(jdbc.queryForObject("SELECT EXISTS(SELECT 1 FROM guests WHERE id=? AND event_id=?)",Boolean.class,guest,event)))
                    throw new ApiProblem(404,"NOT_FOUND","Invité indisponible.");
                UUID id=UUID.randomUUID();
                jdbc.update("INSERT INTO checkins(id,event_id,guest_id,agent_id,entrance_id,request_id) VALUES (?,?,?,?,?,?)",id,event,guest,agent,entrance,request);
                return new CheckinResult(true,findRequest(request).get(0));
            });
        } catch(DataIntegrityViolationException collision) {
            var retry=findRequest(request); if(!retry.isEmpty()) return replay(retry.get(0),event,guest,entrance,agent);
            var existing=findGuest(event,guest); if(!existing.isEmpty())
                throw new ApiProblem(409,"ALREADY_CHECKED_IN","Cette personne est déjà présente.",existing.get(0));
            throw new ApiProblem(409,"CONFLICT","Le contrôle a changé. Actualisez la liste.");
        }
    }
    public Map<String,Object> close(UUID id,String login) {
        if(!"SUPERVISOR".equals(member(id,login).get("role"))) throw new ApiProblem(403,"FORBIDDEN","Seul le superviseur peut fermer l’accueil.");
        return new TransactionTemplate(manager).execute(status -> {
            String state=jdbc.queryForObject("SELECT status FROM events WHERE id=? FOR UPDATE",String.class,id);
            if("CLOSED".equals(state)) return event(id);
            if(!"OPEN".equals(state)) throw new ApiProblem(409,"EVENT_NOT_OPEN","L’accueil n’est pas ouvert.");
            jdbc.update("UPDATE events SET status='CLOSED',closed_at=clock_timestamp(),revision=revision+1 WHERE id=?",id);
            return event(id);
        });
    }
}
