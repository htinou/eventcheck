package fr.eventcheck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventCheckApplication {
    public static void main(String[] args) throws java.io.IOException { LocalSetup.configure(args); SpringApplication.run(EventCheckApplication.class, args); }
}
