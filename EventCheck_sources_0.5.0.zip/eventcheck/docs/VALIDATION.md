# État de livraison — version 0.4

10 octobre 2026. Base H2 embarquée et persistante, profil PostgreSQL facultatif, préparation/import et prototype OCR conservés.

| Vérification | Résultat et portée |
| --- | --- |
| Compilation Angular | Réussie, interface version 0.4 intégrée au JAR |
| Assemblage Java | Réussi, Java 17 / Spring Boot 3.5.16 / H2 2.3.232 |
| Migrations H2/Flyway | Schéma créé automatiquement au premier démarrage, validé sans recréation aux suivants |
| Tests backend | 26 réussis, aucun échec ; un test spécifique à PostgreSQL ignoré |
| Concurrence H2 | 100 courses de trois confirmations : une seule arrivée ; reprise simultanée avec la même clé ; clôture attendant une transaction d’arrivée |
| Préparation concurrente | Deux imports de même révision : un seul accepté ; ouverture et import sérialisés |
| Persistance sur fichier réel | Événement, identifiants invités, présence et heure exacte retrouvés après arrêt/relance ; fichier d’accès inchangé |
| Navigateurs sur H2 fichier | 23 réussis, un corpus volontairement ignoré sur mobile car exécuté sur ordinateur |
| OCR | Traitement local effectivement exécuté ; confidentialité, correction et caméra simulée testées sur les deux viewports |

Le test de persistance lance le JAR avec ses profils par défaut, sans serveur de base, sans DB_URL, et avec un dossier de données isolé. Il effectue une connexion, une arrivée et une création d’événement, arrête proprement le programme et vérifie la récupération après redémarrage. Les tests navigateur suivants utilisent cette même base sur disque et plusieurs sessions. Les tests Java de concurrence utilisent H2 avec un pool de huit connexions, sans sérialisation artificielle par une connexion unique.

Le profil H2 prend un verrou exclusif sur l’événement pendant chaque validation. Il protège la liste et la clôture tout en laissant trois agents utiliser la même instance. Le profil PostgreSQL conserve le verrou partagé prévu à l’origine. Les deux profils possèdent des migrations séparées : le schéma PostgreSQL existant n’est pas réécrit.

Les secrets locaux et les fichiers de base de test sont exclus de l’archive. Le premier démarrage génère les accès dans le dossier utilisateur EventCheck. L’archive contient sources, dépendances verrouillées, lanceurs, JAR avec interface et ressources OCR, documentation et exemples fictifs.

## Limites de validation

- Les lanceurs Windows/macOS sont fournis ; l’exécution réelle du JAR et des tests a été effectuée sous Linux. Java 17 ou ultérieur reste nécessaire.
- Une seule instance ouvre le fichier de base. Les téléphones accèdent à cette instance via navigateur ; chacun n’embarque pas sa propre base.
- Le navigateur mobile testé est un viewport Chromium. Safari/iPhone, Chrome/Android et caméra matérielle restent à qualifier.
- Le corpus OCR synthétique et ses durées sont dans `ocr-validation/corpus.json`. Il ne prouve pas une couverture générale des documents. Aucune photo de pièce réelle n’a été utilisée.
- Le profil PostgreSQL et son test de clôture spécifique restent prévus dans la CI ; cette livraison a été validée sur H2.
- Pas de conversion automatique d’une ancienne base PostgreSQL en H2. Pas d’export ni de purge automatique à ce stade.
- Pas de certificat HTTPS, d’hébergement ou de déploiement réseau automatique. En local, écoute sur 127.0.0.1 ; la caméra sur téléphone exige HTTPS.

## Version 0.5 — 10 octobre 2026

- Backend embarqué : 30 tests, 29 réussis, 1 test PostgreSQL natif ignoré ; aucune erreur. Ajout/édition, ID préservé, référence unique, homonymes, capacité 100, révision concurrente, CSRF, autorisations et liste figée après ouverture vérifiés. Modèle CSV fourni accepté par l’importeur.
- JAR final : Angular compilé et assets OCR locaux présents ; intégrité ZIP vérifiée.
- Navigateurs sur JAR avec H2 fichier : ordinateur 15 réussis, mobile Chromium 14 réussis et 1 corpus ignoré car exécuté une fois. Scénarios existants et gestion unitaire, modèle téléchargeable, lecture OCR réelle sans deux-points réussis.
- Corpus synthétique : 29/30 noms et prénoms correctement extraits. Tests MRZ et libellés bilingues/sur lignes séparées réussis. Les essais ne qualifient pas des pièces réelles ni Safari iPhone.
- GitHub : sources livrées en ZIP, workflows inclus mais non actifs à la racine du dépôt.
