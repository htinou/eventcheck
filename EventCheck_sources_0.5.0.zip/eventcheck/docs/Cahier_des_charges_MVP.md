# EventCheck — Cahier des charges fonctionnel et technique

Version 1.0 · 10 octobre 2026 · Base de développement

## 1. Objectif et décisions de cadrage

Accueillir jusqu’à 100 invités depuis trois entrées simultanées, retrouver leur inscription par nom et prénom, puis enregistrer une seule arrivée par invité et par événement. Le superviseur suit les présents et les attendus et décide de fermer l’accueil.

Ce document décrit une application à développer ; il ne constitue pas une application livrée ni des performances déjà mesurées.

| Sujet | Décision MVP |
| --- | --- |
| Public cible | Petit événement, jusqu’à 100 invités, trois entrées actives |
| Supports | Application web responsive, installable en PWA, iPhone, Android et ordinateur |
| Frontend | Angular, interface commune pour agents et superviseur |
| Backend | Java Spring Boot, API REST |
| Données | PostgreSQL, migrations versionnées |
| Première livraison | Parcours complet par recherche manuelle |
| Deuxième livraison | Caméra et OCR local, après test de faisabilité sur téléphones |
| Synchronisation | Interrogation du serveur chaque seconde quand l’écran est actif |
| Connexion | Obligatoire pour enregistrer une arrivée ; aucune file de validations hors connexion |
| Contrôle | Nominatif simple, confirmation humaine obligatoire |
| Images | Aucune photo de pièce stockée ou envoyée au serveur |

Le rafraîchissement périodique suffit au volume prévu. Des WebSockets pourront être ajoutés ultérieurement si une mesure terrain justifie ce changement. La PWA utilise HTTPS pour la caméra et les échanges réseau. Les versions précises des dépendances seront choisies et verrouillées au démarrage du développement.

## 2. Périmètre et livraisons

### Lot A — Accueil opérationnel sans OCR

- Comptes individuels, connexion et déconnexion.
- Création d’un événement, date et fuseau horaire, trois entrées A/B/C.
- Affectation des agents à l’événement et choix de leur entrée.
- Import CSV ou XLSX des invités, aperçu et erreurs avant confirmation.
- Recherche par nom/prénom, consultation du statut et confirmation d’arrivée.
- Horodatage serveur, enregistrement de l’agent et de l’entrée.
- Protection contre les doubles validations, y compris entre téléphones.
- Supervision des présents, attendus et arrivées par entrée.
- Clôture et export CSV.

### Lot B — MVP complet avec scan

- Capture temporaire d’une CNI ou d’un passeport.
- OCR dans le navigateur, extraction du nom et du prénom uniquement.
- Correction des champs reconnus et recherche dans la liste.
- Même validation serveur que pour la recherche manuelle.

L’OCR est un accélérateur de saisie : il ne certifie ni l’authenticité d’une pièce ni l’identité de son porteur. Le lot A reste utilisable si le scan échoue.

Hors périmètre : reconnaissance faciale, biométrie, conservation des documents, sorties/réentrées, création d’un invité à la volée pendant l’accueil, badges, QR codes, billetterie, SMS, notifications push, statistiques historiques, admission hors connexion et réouverture après clôture. La suppression ou l’annulation d’une arrivée erronée n’est pas incluse en V1 : la fiche de confirmation doit donc être explicite ; ce besoin sera évalué au pilote.

## 3. Rôles et droits

Les droits sont vérifiés dans l’API, sur chaque événement. Masquer un bouton dans l’interface ne suffit pas.

| Action | Agent affecté | Superviseur de l’événement |
| --- | --- | --- |
| Consulter l’événement et ses invités | Oui | Oui |
| Choisir une entrée active | Oui | Oui |
| Rechercher, scanner et confirmer une arrivée | Oui | Oui |
| Consulter les statistiques globales | Compteurs présents/attendus | Tableau complet |
| Créer un événement | Non | Oui, compte autorisé à créer |
| Importer des invités | Non | Oui, état brouillon seulement |
| Affecter des utilisateurs existants | Non | Oui, état brouillon seulement |
| Ouvrir ou clôturer l’accueil | Non | Oui |
| Exporter les listes | Non | Oui |

Les comptes sont provisionnés par l’exploitant pour le pilote ; pas d’inscription publique ni d’envoi automatique d’invitations. Un superviseur peut contrôler une entrée depuis son compte. L’entrée choisie appartient à la session du téléphone et est envoyée lors de la validation : un même utilisateur n’a pas une entrée globale unique dans la table des comptes.

## 4. États et règles métier

### Événement

`DRAFT` → `OPEN` → `CLOSED`.

- DRAFT : préparation, imports, affectations. Pas d’arrivée possible.
- OPEN : inscriptions figées, contrôles autorisés, supervision active.
- CLOSED : contrôles interdits, consultation et export autorisés.
- Ouverture refusée si aucun invité, aucune entrée active ou aucun agent/superviseur affecté.
- Clôture manuelle, après confirmation du nombre d’absents. Aucune clôture automatique à 100 %.
- Une liste vide n’affiche jamais « tout le monde est arrivé ».

### Invité

Un invité est ATTENDU si aucune arrivée n’existe, PRÉSENT sinon. Ce statut est calculé ; pas de champ booléen indépendant qui risquerait de diverger.

| Situation | Comportement attendu |
| --- | --- |
| Correspondance unique | Fiche puis bouton de confirmation |
| Plusieurs candidats ou homonymes | Choix explicite, avec référence d’inscription si disponible |
| Homonymes impossibles à distinguer | Agent sollicite le superviseur ; pas de choix automatique |
| Aucun résultat | Corriger les champs ou rechercher manuellement |
| Invité déjà arrivé | Afficher heure, entrée et agent, bouton désactivé |
| Deux agents confirment le même invité | Une arrivée enregistrée ; l’autre reçoit l’état existant |
| Réponse perdue après enregistrement | Reprendre la même requête avec la même clé ; restituer le résultat existant |
| Connexion coupée | Bandeau, confirmation indisponible, aucune admission annoncée |
| Événement clôturé pendant une validation | Ordre de traitement défini en transaction, pas d’arrivée après la clôture effective |
| Tous présents | Bandeau au superviseur « 100 % des invités sont arrivés » |

Le logiciel garantit l’unicité de l’enregistrement ; il ne peut empêcher physiquement un passage accordé sans confirmation serveur.

## 5. Écrans et parcours

### Connexion — écran transversal

Identifiant, mot de passe, bouton Connexion, erreur générique en cas d’échec. Pas d’affichage des comptes existants. Après connexion, afficher les seuls événements affectés. Déconnexion accessible dans le menu.

### Écran 1 — Mes événements et entrée

Cartes : nom, date locale, statut et compteur présents/inscrits. Au choix d’un événement ouvert, demander « Où contrôlez-vous les arrivées ? » avec Entrée A, B et C. Afficher ensuite l’événement et l’entrée courante dans l’en-tête. Changement d’entrée autorisé avant le prochain contrôle, sans modifier les arrivées précédentes.

États : chargement, aucun événement affecté, accueil non ouvert, accueil clôturé, réseau indisponible.

### Écran 2 — Scanner

Écran ajouté au lot B. Cadre document, bouton Capturer, alternative « Rechercher par nom ». Mention courte : « Image traitée sur ce téléphone, sans conservation ».

Après lecture, montrer Nom et Prénom modifiables avant recherche. Ne pas afficher de faux pourcentage de confiance si le moteur ne fournit pas une mesure exploitable. En cas d’échec, proposer Reprendre ou Recherche manuelle. Arrêter la caméra en quittant cet écran. Libérer l’image et les résultats OCR inutiles ; aucun stockage persistant ni inclusion dans des traces d’erreur.

### Écran 3 — Résultat et confirmation

Nom/prénom en grand, référence d’inscription si renseignée, statut et entrée active. Bouton « Confirmer l’arrivée » uniquement pour un invité attendu, événement ouvert, serveur joignable.

Après appui : état « Confirmation en cours… », bouton désactivé. Le vert « Arrivée enregistrée » apparaît seulement après succès serveur ; afficher l’heure et l’entrée. Bouton « Contrôler la personne suivante ».

Si la requête dépasse cinq secondes, afficher « Résultat à vérifier » et proposer de réessayer avec la même clé. Ne pas affirmer que l’arrivée a échoué tant que son résultat reste inconnu. Une réponse 409 « Déjà présent » affiche le contrôle existant.

### Écran 4 — Recherche manuelle

Champ « Nom ou prénom », saisie filtrée localement sur la liste déjà chargée, sans nouvelle requête à chaque caractère. Résultats : nom, prénom, référence et statut. Filtres Tous/Attendus/Présents. Appui sur un résultat → écran 3.

Recherche sans distinction de casse ou d’accents ; ponctuation, espaces et traits d’union harmonisés. Conserver le nom d’origine pour affichage. Rechercher les tokens saisis dans les champs normalisés, dans n’importe quel ordre. Aucun rapprochement flou automatique en V1. La normalisation ne fusionne jamais deux invités.

### Écran 5 — Préparation superviseur

Nom de l’événement, date, fuseau `Europe/Paris` par défaut, entrées A/B/C, membres affectés, liste des invités, import et aperçu. Colonnes d’import mappables : nom, prénom, référence facultative.

Afficher avant validation : nombre de lignes valides, erreurs avec numéro de ligne, homonymes et total final. Bouton « Ouvrir l’accueil » une fois prêt. Pendant OPEN/CLOSED, les informations de préparation sont consultables ; import et affectations verrouillés.

### Écran 6 — Supervision et rapport

Compteurs inscrits, présents, attendus et taux. Répartition des arrivées par entrée, derniers arrivants, listes filtrables. Bandeau réseau et heure de dernière synchronisation. Bouton Clôturer → dialogue « X personnes sont encore attendues. Fermer l’accueil ? ».

Après clôture : état figé, heure de clôture, export Tous/Présents/Attendus. Message possible si tous présents avant clôture ; la décision de libérer les agents reste au superviseur. Le tableau de bord montre les arrivées par entrée, pas une preuve de présence physique des agents à leur poste.

### Ergonomie commune

Priorité mobile, boutons tactiles d’au moins 44 px, texte lisible, libellés en plus des couleurs, contraste accessible, focus clavier et messages compréhensibles. Pas de données personnelles dans les URL. Préserver le contexte événement/entrée au retour de la recherche. Vérifier iPhone Safari et Android Chrome sur appareils réels.

## 6. Import, capacité et exports

### Import

CSV UTF-8 avec séparateur virgule ou point-virgule ; XLSX, première feuille uniquement, valeurs textuelles sans exécution de formules. Limite de fichier : 2 Mo. En-têtes requis : `nom`, `prenom` ; facultatif : `reference`. Exemple :

```csv
nom;prenom;reference
Martin;Sophie;INV-001
Bernard;Thomas;INV-002
Martin;Sophie;INV-003
```

- Nom et prénom obligatoires après suppression des espaces périphériques ; chacun limité à 100 caractères.
- Référence facultative, maximum 100 caractères ; unique dans un événement quand renseignée.
- Homonymes conservés en lignes distinctes et signalés ; la référence permet de les distinguer.
- Doublon de référence : erreur bloquante. Doublon exact nom/prénom sans référence : avertissement avec confirmation explicite du superviseur.
- Mode V1 : remplacement complet de la liste, uniquement en DRAFT ; pas de fusion incrémentale.
- 100 invités maximum après remplacement, aucune ligne ignorée silencieusement.
- Aperçu sans écriture ; confirmation transactionnelle « tout ou rien ».
- Le fichier confirmé est revalidé côté serveur ; un aperçu client ne fait pas autorité.
- Deux imports concurrents utilisent la révision attendue de l’événement ; le second import périmé est rejeté.
- Fichiers temporaires d’import supprimés après traitement, sans archivage des originaux.

### Export

CSV UTF-8 avec BOM, séparateur point-virgule, colonnes : `reference`, `nom`, `prenom`, `statut`, `arrivee_utc`, `arrivee_locale`, `fuseau`, `entree`, `agent`.

Heures ISO 8601 ; l’heure UTC fait référence, l’heure locale facilite la lecture. Pour un absent, colonnes d’arrivée vides. Export construit à partir d’un instantané cohérent. Échapper séparateurs et guillemets et neutraliser les cellules pouvant être interprétées comme formules par un tableur. Export accessible seulement au superviseur affecté.

## 7. Modèle SQL de référence

Six tables remplacent le modèle préliminaire de quatre tables : les entrées et les affectations sont distinctes pour garantir l’appartenance à l’événement. Les UUID sont générés dans l’application. Ce schéma est une base pour la migration initiale ; les permissions et transitions sont également contrôlées par le service métier.

```sql
CREATE TABLE users (
  id uuid PRIMARY KEY,
  login varchar(254) NOT NULL UNIQUE,
  password_hash text NOT NULL,
  display_name varchar(150) NOT NULL,
  can_create_events boolean NOT NULL DEFAULT false,
  enabled boolean NOT NULL DEFAULT true
);

CREATE TABLE events (
  id uuid PRIMARY KEY,
  name varchar(150) NOT NULL,
  starts_at timestamptz NOT NULL,
  timezone varchar(100) NOT NULL DEFAULT 'Europe/Paris',
  status varchar(10) NOT NULL DEFAULT 'DRAFT'
    CHECK (status IN ('DRAFT','OPEN','CLOSED')),
  revision bigint NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  opened_at timestamptz,
  closed_at timestamptz,
  purge_at timestamptz NOT NULL,
  CHECK (
    (status = 'DRAFT' AND opened_at IS NULL AND closed_at IS NULL) OR
    (status = 'OPEN' AND opened_at IS NOT NULL AND closed_at IS NULL) OR
    (status = 'CLOSED' AND opened_at IS NOT NULL AND closed_at IS NOT NULL)
  )
);

CREATE TABLE entrances (
  id uuid PRIMARY KEY,
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  label varchar(50) NOT NULL,
  active boolean NOT NULL DEFAULT true,
  UNIQUE (event_id, id),
  UNIQUE (event_id, label)
);

CREATE TABLE event_members (
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id),
  role varchar(20) NOT NULL CHECK (role IN ('AGENT','SUPERVISOR')),
  PRIMARY KEY (event_id, user_id)
);

CREATE TABLE guests (
  id uuid PRIMARY KEY,
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  external_ref varchar(100),
  last_name varchar(100) NOT NULL CHECK (length(trim(last_name)) > 0),
  first_name varchar(100) NOT NULL CHECK (length(trim(first_name)) > 0),
  last_name_search varchar(200) NOT NULL,
  first_name_search varchar(200) NOT NULL,
  UNIQUE (event_id, id),
  UNIQUE (event_id, external_ref)
);

CREATE TABLE checkins (
  id uuid PRIMARY KEY,
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  guest_id uuid NOT NULL,
  agent_id uuid NOT NULL,
  entrance_id uuid NOT NULL,
  request_id uuid NOT NULL UNIQUE,
  arrived_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  UNIQUE (event_id, guest_id),
  FOREIGN KEY (event_id, guest_id) REFERENCES guests(event_id, id),
  FOREIGN KEY (event_id, agent_id) REFERENCES event_members(event_id, user_id),
  FOREIGN KEY (event_id, entrance_id) REFERENCES entrances(event_id, id)
);

CREATE INDEX guests_event_idx ON guests(event_id);
CREATE INDEX checkins_event_time_idx ON checkins(event_id, arrived_at DESC);
```

Les références vides sont converties en NULL. La limite de 100 invités et trois entrées actives est contrôlée sous verrou d’événement lors des modifications. Pas de numéro de pièce, date de naissance, adresse ni image dans ce modèle. Les comptes désactivés restent référencés tant que leur historique est conservé.

## 8. Contrat REST

Préfixe `/api/v1`. Identifiants UUID, dates ISO 8601, JSON UTF-8. Cookies de session sécurisés côté serveur ; autorisation par utilisateur et événement. Erreurs structurées `{code, message, details, traceId}` sans trace technique ni donnée de document. Chaque réponse dynamique utilise `Cache-Control: no-store`.

| Méthode et chemin | Usage | Droit |
| --- | --- | --- |
| POST `/auth/login` | Connexion | Public, limité en fréquence |
| POST `/auth/logout` | Déconnexion | Connecté |
| GET `/me` | Utilisateur et capacités | Connecté |
| GET `/events` | Événements affectés | Connecté |
| POST `/events` | Création, trois entrées et affectation du créateur | Créateur autorisé |
| GET `/events/{eventId}` | Détail et entrées | Membre |
| PATCH `/events/{eventId}` | Métadonnées avec révision attendue | Superviseur, DRAFT |
| GET `/assignable-users` | Comptes provisionnés affectables | Créateur autorisé |
| PUT `/events/{eventId}/members` | Affectations et rôles | Superviseur, DRAFT |
| POST `/events/{eventId}/guests/import-preview` | Multipart fichier/mappage, aperçu | Superviseur, DRAFT |
| POST `/events/{eventId}/guests/import` | Multipart fichier/mappage/révision/confirmation avertissements | Superviseur, DRAFT |
| POST `/events/{eventId}/open` | Ouvrir l’accueil | Superviseur |
| GET `/events/{eventId}/snapshot` | Invités, arrivées, compteurs, statut, heure serveur | Membre |
| POST `/events/{eventId}/checkins` | Confirmer l’arrivée | Membre, OPEN |
| POST `/events/{eventId}/close` | Clôturer | Superviseur |
| GET `/events/{eventId}/export?status=all` | CSV ; all/present/expected | Superviseur |

Ne pas permettre au superviseur de retirer sa propre dernière affectation de superviseur. Les comptes affectables ne sont pas exposés aux agents. Le changement d’entrée en session n’a pas besoin d’API de mutation.

### Confirmation d’arrivée

```http
POST /api/v1/events/{eventId}/checkins
Content-Type: application/json
Idempotency-Key: 0b50d18c-fc83-4b0f-a0c4-e4abf60b6eb8

{
  "guestId": "e9e24579-bba4-411f-93a3-a02858fbfd70",
  "entranceId": "9d1ab3e8-02ec-4c87-b9c2-20c6feb86a52"
}
```

L’agent est issu de la session, jamais accepté depuis le corps de requête. La clé est un UUID généré lors du premier appui, conservé pour toute reprise de cette tentative. Elle n’est pas réutilisée pour une autre personne ou entrée.

- 201 : arrivée créée, renvoyer `checkinId`, `guestId`, `arrivedAt`, `entranceId`, `agentId`.
- 200 : reprise de la même requête déjà traitée ; renvoyer le même résultat avec `replayed: true`.
- 409 `ALREADY_CHECKED_IN` : autre tentative pour le même invité ; renvoyer l’arrivée existante.
- 409 `IDEMPOTENCY_KEY_REUSED` : clé déjà utilisée avec un autre invité, événement, entrée ou agent.
- 409 `EVENT_NOT_OPEN` : brouillon ou clôturé.
- 409 `REVISION_CONFLICT` : édition/import sur une révision périmée.
- 400 : requête malformée ; 422 : données d’import invalides.
- 401 : session absente/expirée ; 403 : rôle insuffisant.
- 404 : ressource absente ou événement non accessible ; ne pas dévoiler sa liste.
- 429 : fréquence excessive ; 503 : service indisponible, résultat possiblement inconnu pour une requête interrompue.

### Transaction de validation

1. Authentifier et vérifier l’affectation actuelle à l’événement.
2. Rechercher la clé déjà traitée. Si son contenu et son agent correspondent, restituer le résultat même si l’événement a été clôturé depuis ; sinon rejeter.
3. Verrouiller la ligne événement en lecture partagée (`FOR SHARE`) ; vérifier OPEN et l’entrée active.
4. Vérifier l’invité et son appartenance ; insérer l’arrivée avec la clé et l’heure serveur.
5. L’unicité `(event_id, guest_id)` décide en dernier recours si deux requêtes sont concurrentes. En cas de conflit, sortir proprement de la transaction et relire le résultat pour distinguer reprise, clé réutilisée et arrivée existante.
6. Répondre succès seulement après commit.

La clôture prend un verrou exclusif sur la même ligne événement avant de passer à CLOSED. Elle attend donc la fin des validations déjà engagées ; toute validation ayant acquis le verrou après la clôture est refusée. Les imports et mutations de préparation prennent également ce verrou et vérifient DRAFT et la révision attendue.

Le snapshot lit les données dans une transaction de lecture cohérente, pour que listes et compteurs correspondent. La contrainte SQL, et non le rafraîchissement des écrans, empêche les doublons.

## 9. Synchronisation et réseau

- Un snapshot à l’ouverture puis toutes les secondes sur écran actif ; aucune requête parallèle si la précédente n’est pas terminée.
- Mise à jour immédiate de la fiche à partir de la réponse de validation, puis prochain snapshot pour les compteurs.
- Après retour au premier plan, synchroniser immédiatement avant d’autoriser un contrôle.
- Après échec réseau, marquer les données « non synchronisées », désactiver les nouvelles confirmations et réessayer avec délai progressif plafonné à dix secondes.
- Au rétablissement, charger l’état serveur avant de réactiver les contrôles.
- La liste éventuellement visible hors réseau sert à la consultation seulement. Elle ne fait pas autorité pour admettre quelqu’un.
- Timeout indicatif : cinq secondes. Une arrivée de résultat inconnu garde sa clé ; la reprise ne crée pas de seconde arrivée.

Un rafraîchissement à une seconde vise une propagation en moins de deux secondes quand réseau et serveur fonctionnent normalement. Il ne promet pas ce délai sur une connexion dégradée.

## 10. OCR : exigences et décision de faisabilité

Prototyper un moteur OCR local au navigateur avant de choisir définitivement la bibliothèque. Charger ses ressources techniques séparément des données des invités ; aucune capture ne transite par un prestataire OCR. Le test vérifie aussi que des scripts de suivi ou de rapport d’erreur ne collectent pas la capture.

Prendre en compte les différentes mises en page de CNI et de passeport ; pour un passeport, une lecture MRZ pourra fournir les noms, mais toute autre donnée décodée doit être immédiatement écartée. Les noms composés et translittérations peuvent différer du listing ; la correction reste disponible.

Critère du lot B : sur un corpus de 30 captures autorisées ou synthétiques, représentant plusieurs mises en page et conditions lumineuses, au moins 27 produisent les bons champs de recherche après normalisation ; aucun invité n’est confirmé automatiquement. Cet échantillon valide le pilote et ne prouve pas une couverture générale de toutes les pièces étrangères.

Si la cible échoue sur iPhone, conserver le lot A, améliorer la capture puis comparer un client mobile natif/multiplateforme utilisant la même API. Ne pas substituer silencieusement un OCR cloud au traitement local prévu.

## 11. Protection des données et exploitation

Exigences de conception, à faire valider par l’organisateur avant un usage réel :

- Collecter nom, prénom, référence d’inscription facultative et présence uniquement.
- Informer les invités du traitement selon le dispositif retenu par l’organisateur.
- Prévoir un contrôle manuel quand le scan n’est pas utilisé.
- Date de purge obligatoire ; proposition de départ : 30 jours après la date de l’événement, configurable avant ouverture. Ce délai est un choix produit à valider, pas une durée légale imposée.
- Purge planifiée de l’événement et de ses invités/arrivées, avec suppression explicite des arrivées avant invités puis de l’événement. Les exports téléchargés sont à gérer séparément par l’organisateur.
- Définir aussi une expiration des sauvegardes et éviter qu’une restauration ne réintroduise durablement des données déjà purgées.
- HTTPS, cookies HttpOnly/Secure/SameSite, protection CSRF des mutations et contrôle d’accès systématique.
- Mots de passe hachés avec un algorithme adapté, limitation des tentatives de connexion, secrets hors dépôt.
- Pas de nom, document, OCR brut ou corps d’import dans les logs. Traces techniques avec identifiants de requête et durées ; journaliser les opérations sensibles avec leurs identifiants et actor, sans copie des listes.
- Aucune réponse API nominative mise en cache par le service worker. Cache PWA limité aux ressources statiques ; nettoyage des données de session et de la liste en mémoire à la déconnexion.

Le cadre de présentation d’une pièce et la base juridique du traitement restent à confirmer par l’organisateur ; ce cahier des charges n’apporte pas une validation juridique.

## 12. Performances et recette

Objectifs à mesurer sur 100 invités, trois téléphones agents et un superviseur, serveur de test représentatif. Les seuils réseau ci-dessous concernent une connexion stable, latence aller-retour ≤ 150 ms. Mesurer au moins 100 opérations ; rapporter p50, p95 et erreurs. La recherche locale est mesurée sur chaque téléphone cible.

| Mesure | Cible |
| --- | --- |
| Filtrage manuel après saisie | p95 < 0,5 s |
| Confirmation appui → succès visible | p95 < 1 s |
| Arrivée visible sur les autres écrans actifs | p95 < 2 s |
| Chargement initial du dashboard connecté | p95 < 2 s |
| OCR après capture, hors premier chargement du moteur | p95 ≤ 3 s, à valider en lot B |
| Doubles arrivées en base pour un invité | 0 |
| Charge de recette | 4 sessions actives, 3 validations concurrentes |

Prévoir un test d’une heure à quatre sessions et un test de 100 arrivées. Mesurer séparément premier chargement, OCR et temps de présentation du document. À 12 secondes par invité et une répartition équilibrée, 100 invités / 3 entrées ≈ 6 min 40 s de traitement théorique ; la fenêtre d’accueil réelle dépend des arrivées, incidents et contrôles humains.

### Critères d’acceptation

| ID | Scénario | Résultat exigé |
| --- | --- | --- |
| A01 | Import de 100 lignes valides | 100 invités, aucun ajout partiel |
| A02 | Import de 101 lignes ou référence répétée | Rejet intégral avec erreurs compréhensibles |
| A03 | Deux imports sur la même révision | Premier accepté, second rejeté comme périmé |
| A04 | Recherche « elodie » pour Élodie | Invitée retrouvée, orthographe originale conservée |
| A05 | Deux Sophie Martin inscrites | Deux fiches distinctes, choix humain obligatoire |
| A06 | Trois agents confirment le même invité simultanément | Une ligne, un 201 et deux réponses d’arrivée existante |
| A07 | Cent répétitions du test concurrent sur PostgreSQL | Aucun doublon ni erreur serveur non gérée |
| A08 | Réponse perdue après commit puis reprise même clé | Même arrivée et même heure ; réponse de reprise |
| A09 | Même clé avec un autre invité ou agent | Rejet sans nouvelle écriture |
| A10 | Deux invités différents contrôlés en parallèle | Les deux arrivées acceptées |
| A11 | Entrée ou invité d’un autre événement | Rejet sans écriture |
| A12 | Agent appelle clôture/import/export | Refus côté API |
| A13 | Coupure réseau | Pas de confirmation verte ni file de validations locales |
| A14 | Retour réseau ou retour d’arrière-plan | Snapshot récent avant nouvelles confirmations |
| A15 | Clôture concurrente à une arrivée | Ordre transactionnel respecté, aucune arrivée post-clôture |
| A16 | Dernier invité arrive | Message 100 %, événement reste ouvert |
| A17 | Export | Tous = présents + attendus ; heures/entrées exactes |
| A18 | Valeur commençant par une formule dans un nom | CSV neutralisé pour ouverture dans un tableur |
| A19 | Déconnexion et navigation arrière | Liste non accessible sans authentification |
| A20 | Capture OCR | Ni image sur le réseau, ni stockage persistant, ni log OCR |
| A21 | Purge à échéance | Données événementielles supprimées, autres événements intacts |
| A22 | Parcours sur iPhone et Android réels | Recherche, validation, supervision et scan testés selon lot |

Les tests de concurrence doivent utiliser PostgreSQL réel, pas une base de substitution. Pour A08, simuler une perte de réponse après commit, pas seulement une requête jamais reçue. Pour A15, tester les deux ordres de prise de verrou. Les objectifs de performance restent des cibles jusqu’au rapport de recette.

## 13. Plan de développement

| Étape | Travail | Livrable vérifiable |
| --- | --- | --- |
| 1 | Squelette Angular/API, migrations, jeu de données fictif | Démarrage local documenté |
| 2 | Session, rôles, préparation et import | Événement de 100 invités prêt à ouvrir |
| 3 | Validation transactionnelle et idempotence | Tests A06–A12 et A15 exécutés |
| 4 | Écrans agents et supervision, rafraîchissement | Démonstration avec trois sessions |
| 5 | CSV, clôture, purge, états réseau | Lot A complet et recette fonctionnelle |
| 6 | Prototype caméra/OCR et mesure terrain | Décision de faisabilité lot B |
| 7 | Intégration OCR et pilote | Recette sur trois téléphones avec données autorisées |

Organisation suggérée : `frontend/`, `backend/`, `infra/`, `docs/`. Démarrage local avec PostgreSQL et API, configuration d’exemple sans secrets, données de démonstration fictives. Déployer une instance de recette en HTTPS accessible aux trois téléphones, avec sessions partagées côté serveur ou une seule instance API pour le pilote. Prévoir sauvegardes et procédure de restauration vérifiée avant usage réel.

Estimation indicative : deux à quatre semaines pour le lot A avec un développeur à l’aise avec Angular/Java et une portée stable ; lot B à chiffrer après le prototype OCR. Aucune date d’événement n’a été communiquée, donc aucun engagement calendaire n’est fixé.

## 14. Premier ticket prêt à développer

**Titre : initialiser EventCheck et démontrer une arrivée unique.**

Créer le squelette Angular/Spring Boot/PostgreSQL, la migration des six tables et un jeu fictif : un événement, trois entrées, trois agents, un superviseur et dix invités dont deux homonymes. Implémenter connexion, liste des événements affectés, snapshot et confirmation d’arrivée. Ajouter un écran mobile de recherche/confirmation et un compteur superviseur actualisé chaque seconde.

Définition de terminé : démarrage reproductible documenté, secrets absents du dépôt, recherche puis validation depuis trois sessions, tests d’intégration de validation concurrente, reprise idempotente et isolation entre événements. À ce stade, données de démonstration uniquement ; import, clôture complète et OCR sont les tickets suivants.

Points à confirmer pendant le pilote, sans bloquer cette première étape : appareils réels disponibles, qualité de connexion sur les trois entrées, représentativité des documents, besoin éventuel de correction d’une arrivée, durée de conservation retenue et procédure face à des homonymes sans référence.
