@echo off
cd /d "%~dp0"
set DB_URL=
set DB_USER=
set DB_PASSWORD=
set DEMO_PASSWORD=
set SPRING_PROFILES_ACTIVE=embedded,demo
java -jar release\eventcheck.jar
pause
