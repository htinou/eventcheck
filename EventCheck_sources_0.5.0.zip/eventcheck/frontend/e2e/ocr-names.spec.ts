import {test,expect} from '@playwright/test';
import {extractNames} from '../src/ocr-names';
test('noms sans deux-points, libellés bilingues et lignes séparées',()=>{
 expect(extractNames('Nom / Surname\nLE GOFF\nPrénoms / Given names\nAnne-Marie')).toEqual({lastName:'LE GOFF',firstName:'Anne-Marie'});
 expect(extractNames('Nom Dubois\nPrénom Élodie')).toEqual({lastName:'Dubois',firstName:'Élodie'});
 expect(extractNames('Surname: Ben Ali\nGiven names: Karim')).toEqual({lastName:'Ben Ali',firstName:'Karim'});
 expect(extractNames('Nom\nPrénom\nDATE DE NAISSANCE 01/01/1990')).toEqual({lastName:'',firstName:''});
 expect(extractNames('IDFRAABCDEFGHI123456789012345678\n9001011F3001012FRA<<<<<<<<<<<123\nMARTIN<<SOPHIE<<<<<<<<<<<<<<<<<')).toEqual({lastName:'MARTIN',firstName:'SOPHIE'});
 expect(extractNames('123456789\nMARTIN<<SOPHIE')).toEqual({lastName:'',firstName:''});
});

test('extraction prudente, noms composés et MRZ sans autres données',()=>{
 expect(extractNames('Nom: Le Goff\nPrénom: Anne-Marie\nDate de naissance: 1990-01-01')).toEqual({lastName:'Le Goff',firstName:'Anne-Marie'});
 expect(extractNames('P<FRALE<GOFF<<ANNE<MARIE<<<<<<<<<<<<<<<<<<<<\n1234567890FRA9001012F3001010<<<<<<<<<<<<<<02')).toEqual({lastName:'LE GOFF',firstName:'ANNE MARIE'});
 expect(extractNames('DOCUMENT\n19900101\n123456789')).toEqual({lastName:'',firstName:''});
});
