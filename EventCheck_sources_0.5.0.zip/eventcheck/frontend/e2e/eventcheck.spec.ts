import {test,expect,Page} from '@playwright/test';
const password=process.env['DEMO_PASSWORD'];
test.skip(!password,'DEMO_PASSWORD doit correspondre à la base de démonstration.');
async function login(page:Page,user='accueil.a'){
  await page.goto('/');await page.getByLabel('Identifiant',{exact:true}).fill(user);await page.getByLabel('Mot de passe',{exact:true}).fill(password!);
  await page.getByRole('button',{name:'Se connecter'}).click();await page.getByRole('button',{name:/Rencontres EventCheck/}).click();
}
test('recherche normalisée et homonymes',async({page})=>{
  await login(page);await page.getByLabel('Nom ou prénom',{exact:true}).fill('elodie');await expect(page.getByRole('table')).toContainText('Élodie');
  await page.getByLabel('Nom ou prénom',{exact:true}).fill('sophie martin');await expect(page.locator('tbody tr')).toHaveCount(2);
  await page.getByRole('button',{name:'Voir Sophie Martin INV-001',exact:true}).click();
  await expect(page.getByRole('dialog')).toContainText('INV-001');
});
test('supervision et refus de clôture pour un agent',async({page})=>{
  await login(page,'supervision');await expect(page.getByRole('heading',{name:'Les trois entrées'})).toBeVisible();
  await page.getByRole('button',{name:'Déconnexion'}).click();await login(page,'accueil.b');
  await expect(page.getByRole('button',{name:'Supervision',exact:true})).toHaveCount(0);
  await expect(page.getByRole('button',{name:/Clôturer l’accueil/})).toHaveCount(0);
});
test('coupure réseau suspend les nouvelles confirmations',async({page,context})=>{
  await login(page);await context.setOffline(true);await expect(page.getByRole('alert')).toContainText('Connexion à vérifier');
  await context.setOffline(false);await expect(page.getByText('Synchronisé',{exact:true})).toBeVisible({timeout:15000});
});
test('deux sessions partagent une arrivée sans doublon',async({page,browser},testInfo)=>{
  await login(page,'supervision');const agentContext=await browser.newContext();const agent=await agentContext.newPage();await login(agent,'accueil.c');
  await agent.getByLabel('Votre entrée',{exact:true}).selectOption({label:'Entrée C'});
  const name=testInfo.project.name==='mobile'?'Lucas Moreau':'Aarav Singh';
  await agent.getByLabel('Nom ou prénom',{exact:true}).fill(name);await agent.getByRole('button',{name:new RegExp('Voir '+name)}).click();
  await expect(agent.getByRole('dialog')).toBeVisible();
  const confirm=agent.getByRole('button',{name:/Confirmer l’arrivée/});
  if(await confirm.count()){await confirm.click();await expect(agent.getByRole('status')).toContainText('Arrivée enregistrée');}
  await expect(page.locator('tbody tr').filter({hasText:name})).toContainText('Présent',{timeout:5000});
  await expect(page.locator('tbody tr').filter({hasText:name})).toContainText('Entrée C');
  await agentContext.close();
});
test('données personnelles absentes après déconnexion',async({page})=>{
  await login(page);await page.getByRole('button',{name:'Déconnexion'}).click();
  await expect(page.getByLabel('Identifiant',{exact:true})).toBeVisible();await expect(page.getByRole('table')).toHaveCount(0);
});
test('réponse perdue après enregistrement, puis reprise de la même tentative',async({page},testInfo)=>{
  const name=testInfo.project.name==='mobile'?'Thomas Bernard':'Camille Roy';
  await login(page,'accueil.a');await page.getByLabel('Nom ou prénom',{exact:true}).fill(name);
  await page.getByRole('button',{name:new RegExp('Voir '+name)}).click();await expect(page.getByRole('dialog')).toBeVisible();
  const confirm=page.getByRole('button',{name:/Confirmer l’arrivée/});
  test.skip(!await confirm.count(),'La fixture est déjà présente ; utiliser une base de démonstration neuve pour ce scénario.');
  await page.route('**/checkins',async route=>{await route.fetch();await route.abort('failed');},{times:1});
  await confirm.click();await expect(page.getByRole('dialog')).toContainText('Résultat à vérifier');
  const retry=page.getByRole('button',{name:/Vérifier cette confirmation/});await expect(retry).toBeEnabled();await retry.click();
  await expect(page.getByRole('dialog')).toContainText('confirmation retrouvée');
});
