import {mkdirSync,copyFileSync} from 'node:fs';
const root=new URL('../',import.meta.url);
const target=new URL('public/ocr/',root);mkdirSync(target,{recursive:true});
for(const name of ['tesseract-core-lstm.wasm.js','tesseract-core-simd-lstm.wasm.js'])copyFileSync(new URL('node_modules/tesseract.js-core/'+name,root),new URL(name,target));
copyFileSync(new URL('node_modules/tesseract.js/dist/worker.min.js',root),new URL('worker.min.js',target));
copyFileSync(new URL('node_modules/@tesseract.js-data/fra/4.0.0_best_int/fra.traineddata.gz',root),new URL('fra.traineddata.gz',target));
copyFileSync(new URL('node_modules/tesseract.js/LICENSE.md',root),new URL('LICENSE-tesseract.txt',target));
copyFileSync(new URL('node_modules/tesseract.js-core/LICENSE',root),new URL('LICENSE-core.txt',target));
