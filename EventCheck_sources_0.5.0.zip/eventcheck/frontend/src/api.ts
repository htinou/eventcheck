export class ApiError extends Error {
  constructor(public status:number, public code:string, message:string, public details:unknown={}) { super(message); }
}
let csrfToken = '';
export async function refreshCsrf():Promise<void> {
  const response=await fetch('/api/v1/auth/csrf',{credentials:'same-origin',cache:'no-store'});
  if(!response.ok) throw new ApiError(response.status,'CSRF_UNAVAILABLE','La session ne peut pas être initialisée.');
  csrfToken=(await response.json()).token;
}
export async function api<T>(path:string, method='GET', body?:unknown, headers:Record<string,string>={}):Promise<T> {
  if(method!=='GET'&&!csrfToken) await refreshCsrf();
  const controller=new AbortController(); const timeout=setTimeout(()=>controller.abort(),5000);
  try {
    const response=await fetch('/api/v1'+path,{method,credentials:'same-origin',cache:'no-store',signal:controller.signal,
      headers:{...(body!==undefined&&!(body instanceof FormData)?{'Content-Type':'application/json'}:{}),...(method!=='GET'?{'X-CSRF-TOKEN':csrfToken}:{}),...headers},
      ...(body!==undefined?{body:body instanceof FormData?body:JSON.stringify(body)}:{})});
    const data=await response.json();
    if(!response.ok) throw new ApiError(response.status,data.code??'REQUEST_FAILED',data.message??'La demande a échoué.',data.details);
    return data as T;
  } catch(error) {
    if(error instanceof ApiError) throw error;
    throw new ApiError(0,'NETWORK_UNKNOWN','Le serveur ne répond pas. Vérifiez la connexion.');
  } finally { clearTimeout(timeout); }
}
