// Return only name fields, never document identifiers or other personal fields.
export function extractNames(text:string):{lastName:string;firstName:string} {
  const lines=text.split(/\r?\n/).map(l=>l.trim()).filter(Boolean);
  const clean=(s:string)=>s.replace(/</g,' ').replace(/[^\p{L}\p{M}\s’'\-]/gu,'').replace(/\s+/g,' ').trim().slice(0,100);
  const normalize=(s:string)=>s.normalize('NFD').replace(/\p{M}/gu,'').toUpperCase();
  for(let i=0;i<lines.length;i++){
    const mrz=lines[i].toUpperCase().replace(/\s/g,'');
    if(/^P<[A-Z<]{3}[A-Z<]{5,39}$/.test(mrz)&&mrz.length>=30){
      const parts=mrz.slice(5).split('<<');
      if(parts.length>=2)return {lastName:clean(parts[0]),firstName:clean(parts.slice(1).join(' '))};
    }
    // TD1 cards: the third MRZ row contains names. Require the two preceding
    // MRZ rows to avoid guessing from an arbitrary line elsewhere in the photo.
    if(i>=2&&/^I[A-Z<][A-Z<]{3}[A-Z0-9<]{20,}$/.test(lines[i-2].toUpperCase().replace(/\s/g,''))&&/^[A-Z0-9<]{25,}$/.test(lines[i-1].toUpperCase().replace(/\s/g,''))&&/^[A-Z<]{2,}<<[A-Z<]+$/.test(mrz)){
      const parts=mrz.split('<<');return {lastName:clean(parts[0]),firstName:clean(parts.slice(1).join(' '))};
    }
  }
  const lastLabel=/^(?:NOM(?: DE FAMILLE)?|SURNAME|LAST NAME)(?:\s*\/\s*(?:SURNAME|NOM))?(?=\s|[:：]|$)\s*[:：]?\s*/;
  const firstLabel=/^(?:PRENOMS?|GIVEN NAMES?|FIRST NAME)(?:\s*\/\s*(?:GIVEN NAMES?|PRENOMS?))?(?=\s|[:：]|$)\s*[:：]?\s*/;
  const otherLabel=/^(?:DATE|SEXE|SEX|NATIONALIT|LIEU|PLACE|NUMERO|DOCUMENT|EXPIR|DELIV|BIRTH|SIGNATURE|PERSONAL|ADDRESS|ADRESSE|TAILLE)/;
  const valueAfter=(i:number,length:number)=>{
    const inline=lines[i].slice(length).trim();if(inline)return clean(inline);
    const next=lines[i+1]??'';const n=normalize(next);
    return lastLabel.test(n)||firstLabel.test(n)||otherLabel.test(n)||/\d/.test(next)?'':clean(next);
  };
  let lastName='',firstName='';
  for(let i=0;i<lines.length;i++){
    const label=normalize(lines[i]);const last=lastLabel.exec(label),first=firstLabel.exec(label);
    if(last)lastName=valueAfter(i,last[0].length);
    if(first)firstName=valueAfter(i,first[0].length);
  }
  return {lastName,firstName};
}
