import {Component, computed, signal, OnDestroy} from '@angular/core';
import {bootstrapApplication} from '@angular/platform-browser';
import {PreparationComponent} from './preparation';
import {OcrComponent} from './ocr';
import {api, ApiError, refreshCsrf} from './api';

interface User {id:string; login:string; displayName:string; canCreateEvents:boolean;}
interface EventItem {id:string; name:string; startsAt:string; timezone:string; status:'DRAFT'|'OPEN'|'CLOSED'; role:'AGENT'|'SUPERVISOR'; total:number; present:number;}
interface Entrance {id:string; label:string; active:boolean;}
interface Guest {id:string; firstName:string; lastName:string; reference:string|null; search:string; status:'EXPECTED'|'PRESENT'; arrivedAt:string|null; entranceId:string|null; entranceLabel:string|null; agentName:string|null;}
interface Snapshot {event:EventItem; role:'AGENT'|'SUPERVISOR'; entrances:Entrance[]; guests:Guest[]; total:number; present:number; expected:number; serverTime:string;}
interface Pending {key:string; eventId:string; guestId:string; entranceId:string;}
interface Checkin {guestId:string; arrivedAt:string; entranceId:string; agentId:string; agentName:string; entranceLabel:string; replayed?:boolean;}

@Component({selector:'app-root',standalone:true,imports:[PreparationComponent,OcrComponent],templateUrl:'./app.html'})
class App implements OnDestroy {
  readonly scanning=signal(false);
  scanSearch(query:string):void {this.query.set(query);this.filter.set('all');this.scanning.set(false);}
  readonly user=signal<User|null>(null); readonly events=signal<EventItem[]>([]); readonly snapshot=signal<Snapshot|null>(null);
  readonly screen=signal<'events'|'checkin'|'dashboard'|'prepare'>('events'); readonly entranceId=signal(''); readonly query=signal('');
  readonly filter=signal<'all'|'expected'|'present'>('all'); readonly selectedId=signal<string|null>(null);
  readonly healthy=signal(false); readonly busy=signal(false); readonly loading=signal(true); readonly notice=signal('');
  readonly pending=signal<Pending|null>(null); readonly outcome=signal<'success'|'duplicate'|'unknown'|null>(null);
  readonly closeConfirm=signal(false); readonly loginName=signal(''); readonly password=signal(''); readonly loginError=signal('');
  readonly lastSync=signal<Date|null>(null); readonly syncing=signal(false);
  private timer:ReturnType<typeof setTimeout>|null=null; private running=false; private destroyed=false; private failures=0; private generation=0;
  readonly filtered=computed(()=>{
    const tokens=this.normalize(this.query()).split(' ').filter(Boolean);
    return (this.snapshot()?.guests??[]).filter(g=>tokens.every(t=>g.search.includes(t))
      && (this.filter()==='all'||(this.filter()==='present')===(g.status==='PRESENT')));
  });
  readonly selected=computed(()=>this.snapshot()?.guests.find(g=>g.id===this.selectedId())??null);
  readonly entrance=computed(()=>this.snapshot()?.entrances.find(e=>e.id===this.entranceId())??null);
  readonly percent=computed(()=>{const s=this.snapshot();return s?.total?Math.round(s.present/s.total*100):0;});
  readonly recent=computed(()=>(this.snapshot()?.guests??[]).filter(g=>g.arrivedAt).sort((a,b)=>b.arrivedAt!.localeCompare(a.arrivedAt!)).slice(0,5));
  readonly homonyms=computed(()=>{const g=this.selected();return g?this.snapshot()!.guests.filter(x=>x.search===g.search).length:0;});
  constructor() { void this.initialize(); document.addEventListener('visibilitychange',this.visibility); window.addEventListener('offline',this.offline); window.addEventListener('online',this.online); }
  private normalize(value:string):string {return value.normalize('NFD').replace(/\p{M}/gu,'').toLocaleLowerCase('fr').replace(/[^\p{L}\p{N}]+/gu,' ').trim().replace(/\s+/g,' ');}
  initials(g:Guest):string {return (g.firstName[0]+g.lastName[0]).toUpperCase();}
  time(value:string|null):string {return value?new Date(value).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit',second:'2-digit',timeZone:this.snapshot()?.event.timezone??'Europe/Paris'}):'—';}
  date(value:string):string {return new Date(value).toLocaleDateString('fr-FR',{day:'numeric',month:'long',year:'numeric'});}
  count(entrance:string):number {return this.snapshot()?.guests.filter(g=>g.entranceId===entrance).length??0;}
  trackValue(event:Event):string {return (event.target as HTMLInputElement).value;}
  private async initialize():Promise<void> {
    try {await refreshCsrf();this.user.set(await api<User>('/me'));await this.loadEvents();}
    catch(error) {if(!(error instanceof ApiError&&error.status===401))this.loginError.set('Le serveur est indisponible. Réessayez dans un instant.');}
    finally {this.loading.set(false);}
  }
  async login(event:Event):Promise<void> {
    event.preventDefault();this.busy.set(true);this.loginError.set('');
    try {await refreshCsrf();const user=await api<User>('/auth/login','POST',{login:this.loginName(),password:this.password()});this.password.set('');await refreshCsrf();this.user.set(user);await this.loadEvents();}
    catch(error) {this.loginError.set((error as Error).message);this.password.set('');}
    finally {this.busy.set(false);}
  }
  private async loadEvents():Promise<void> {this.events.set(await api<EventItem[]>('/events'));}
  async choose(event:EventItem):Promise<void> {
    this.scanning.set(false);this.stopTimer();this.generation++;this.snapshot.set(null);this.selectedId.set(null);this.query.set('');this.filter.set('all');this.notice.set('');this.outcome.set(null);this.closeConfirm.set(false);this.healthy.set(false);this.entranceId.set('');this.lastSync.set(null);this.loading.set(true);
    try {const data=await api<Snapshot>('/events/'+event.id+'/snapshot');this.snapshot.set(data);this.entranceId.set(data.entrances.find(e=>e.active)?.id??'');this.screen.set(data.role==='SUPERVISOR'?(data.event.status==='DRAFT'?'prepare':'dashboard'):'checkin');this.healthy.set(true);this.lastSync.set(new Date());this.failures=0;this.schedule();}
    catch(error) {this.notice.set((error as Error).message);if(error instanceof ApiError&&error.status===401)this.expired();}
    finally {this.loading.set(false);}
  }
  readonly creating=signal(false); createName='';createDate='';
  async create(event:Event):Promise<void>{event.preventDefault();this.busy.set(true);this.notice.set('');try{const d=await api<EventItem>('/events','POST',{name:this.createName,startsAtLocal:this.createDate,timezone:'Europe/Paris'});this.creating.set(false);await this.choose(d);}catch(e){this.notice.set((e as Error).message);}finally{this.busy.set(false);}}
  async opened():Promise<void>{await this.refresh();this.screen.set('dashboard');}
  async back():Promise<void> {if(this.pending()||this.busy())return;this.scanning.set(false);this.stopTimer();this.generation++;this.snapshot.set(null);this.selectedId.set(null);this.screen.set('events');this.notice.set('');this.closeConfirm.set(false);try{await this.loadEvents();}catch(error){this.notice.set((error as Error).message);}}
  select(g:Guest):void {if(this.pending()||this.busy())return;this.selectedId.set(g.id);this.notice.set('');this.outcome.set(null);}
  dismiss():void {if(!this.pending()&&!this.busy()){this.selectedId.set(null);this.notice.set('');this.outcome.set(null);}}
  changeEntrance(event:Event):void {if(!this.pending()&&!this.busy())this.entranceId.set(this.trackValue(event));}
  async confirm():Promise<void> {
    const snapshot=this.snapshot(),guest=this.selected();
    if(!snapshot||!guest||!this.healthy()||this.busy()||snapshot.event.status!=='OPEN'||!this.entrance())return;
    if(!this.pending()&&guest.status==='PRESENT')return;
    const pending=this.pending()??{key:crypto.randomUUID(),eventId:snapshot.event.id,guestId:guest.id,entranceId:this.entranceId()};
    this.pending.set(pending);this.busy.set(true);this.notice.set('');
    try {
      const result=await api<Checkin>('/events/'+pending.eventId+'/checkins','POST',{guestId:pending.guestId,entranceId:pending.entranceId},{'Idempotency-Key':pending.key});
      this.applyArrival(result);this.pending.set(null);this.outcome.set('success');this.notice.set('Arrivée enregistrée'+(result.replayed?' · confirmation retrouvée':''));
    } catch(error) {
      if(error instanceof ApiError&&error.code==='ALREADY_CHECKED_IN') {this.applyArrival(error.details as Checkin);this.pending.set(null);this.outcome.set('duplicate');this.notice.set('Cette personne est déjà présente.');}
      else if(error instanceof ApiError&&(error.status===0||error.status>=500)) {this.outcome.set('unknown');this.notice.set('Résultat à vérifier. Réessayez cette même confirmation dès que le serveur est disponible.');this.healthy.set(false);}
      else {this.pending.set(null);this.outcome.set(null);this.notice.set((error as Error).message);if(error instanceof ApiError&&error.status===401)this.expired();}
    } finally {this.busy.set(false);await this.refresh();}
  }
  private applyArrival(result:Checkin):void {
    const s=this.snapshot();if(!s)return;
    const guests=s.guests.map(g=>g.id===result.guestId?{...g,status:'PRESENT' as const,arrivedAt:result.arrivedAt,entranceId:result.entranceId,entranceLabel:result.entranceLabel,agentName:result.agentName}:g);
    const present=guests.filter(g=>g.status==='PRESENT').length;this.snapshot.set({...s,guests,present,expected:s.total-present});
  }
  async close():Promise<void> {
    const s=this.snapshot();if(!s||!this.healthy()||this.busy())return;this.busy.set(true);
    try {await api('/events/'+s.event.id+'/close','POST',{});this.closeConfirm.set(false);this.notice.set('L’accueil est clôturé.');}
    catch(error){this.notice.set((error as Error).message);}
    finally{this.busy.set(false);await this.refresh();}
  }
  async logout():Promise<void> {
    if(this.pending()||this.busy())return;this.busy.set(true);
    try {await api('/auth/logout','POST',{});this.expired();await refreshCsrf();}
    catch(error){this.notice.set((error as Error).message);}
    finally{this.busy.set(false);}
  }
  private expired():void {this.scanning.set(false);this.creating.set(false);this.createName="";this.createDate="";this.stopTimer();this.generation++;this.user.set(null);this.events.set([]);this.snapshot.set(null);this.selectedId.set(null);this.pending.set(null);this.closeConfirm.set(false);this.healthy.set(false);this.screen.set('events');this.loginError.set('Reconnectez-vous pour continuer.');}
  private schedule():void {this.stopTimer();if(!document.hidden&&this.snapshot()&&!this.destroyed)this.timer=setTimeout(()=>void this.refresh(),Math.min(1000*2**this.failures,10000));}
  private stopTimer():void {if(this.timer)clearTimeout(this.timer);this.timer=null;}
  async refresh():Promise<void> {
    const s=this.snapshot();if(!s||this.running)return;const generation=this.generation;this.running=true;this.syncing.set(true);
    try {const data=await api<Snapshot>('/events/'+s.event.id+'/snapshot');if(generation!==this.generation)return;this.snapshot.set(data);this.lastSync.set(new Date());this.healthy.set(true);this.failures=0;}
    catch(error){if(generation!==this.generation)return;this.healthy.set(false);this.failures++;if(error instanceof ApiError&&error.status===401)this.expired();}
    finally{this.running=false;this.syncing.set(false);this.schedule();}
  }
  private readonly offline=()=>this.healthy.set(false);
  private readonly online=()=>void this.refresh();
  private readonly visibility=()=>{if(document.hidden){this.stopTimer();this.healthy.set(false);}else{this.healthy.set(false);void this.refresh();}};
  ngOnDestroy():void {this.destroyed=true;this.stopTimer();document.removeEventListener('visibilitychange',this.visibility);window.removeEventListener('offline',this.offline);window.removeEventListener('online',this.online);}
}
bootstrapApplication(App).catch(()=>{document.body.textContent='EventCheck ne peut pas démarrer. Actualisez la page.';});
