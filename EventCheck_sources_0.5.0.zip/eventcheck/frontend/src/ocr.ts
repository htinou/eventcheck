import {Component,ElementRef,ViewChild,Output,EventEmitter,OnDestroy,signal} from '@angular/core';
import {createWorker,OEM,PSM,Worker} from 'tesseract.js';
import {extractNames} from './ocr-names';
@Component({selector:'event-ocr',standalone:true,template:`
<section class="panel ocr-panel"><div class="eyebrow">PROTOTYPE · À QUALIFIER SUR TÉLÉPHONES</div><h2>Lire un nom, puis vérifier.</h2><p class="muted">Image traitée sur ce téléphone, sans envoi ni conservation. Ce scan ne vérifie pas l’authenticité d’une pièce ni l’identité de son porteur.</p>
<p class="small-text">Cadrez seulement les champs Nom et Prénom, assez près pour que les lettres soient nettes. Sur téléphone, la caméra nécessite HTTPS ; le choix d’une photo reste disponible.</p>
<video #video autoplay playsinline muted [hidden]="!camera()" aria-label="Aperçu de la caméra"></video>
@if(camera()){<p class="small-text">Cadrez la zone du nom et du prénom, avec un éclairage uniforme.</p><button class="primary" (click)="capture()" [disabled]="busy()">Capturer et lire</button>}
@if(!busy()&&!result()){<button class="primary" (click)="start()">Utiliser la caméra</button><label class="ocr-file">Ou choisir une photo sur ce téléphone<input type="file" accept="image/*" (change)="upload($event)"></label>}
@if(busy()){<p role="status">{{status()}}</p><button class="text-btn" (click)="cancel()">Annuler la lecture</button>}
@if(message()){<p class="homonym" role="status">{{message()}}</p>}
@if(result()){<form (submit)="search($event)"><div class="prep-fields"><label>Nom lu<input maxlength="100" [value]="lastName" (input)="lastName=value($event)"></label><label>Prénom lu<input maxlength="100" [value]="firstName" (input)="firstName=value($event)"></label></div><p class="muted">Vérifiez et corrigez les champs. Aucune arrivée n’est confirmée par le scan.</p><button class="primary" [disabled]="!lastName.trim()&&!firstName.trim()">Rechercher ces noms →</button><button type="button" class="text-btn" (click)="reset()">Reprendre</button></form>}
<button class="text-btn" (click)="manual()">Rechercher par nom sans scan →</button></section>
`})
export class OcrComponent implements OnDestroy {
 @ViewChild('video',{static:true}) video!:ElementRef<HTMLVideoElement>;
 @Output() names=new EventEmitter<string>();@Output() dismissed=new EventEmitter<void>();
 camera=signal(false);busy=signal(false);result=signal(false);message=signal('');status=signal('Préparation du moteur local…');lastName='';firstName='';
 private canvas:HTMLCanvasElement|null=null;private stream:MediaStream|null=null;private worker:Worker|null=null;private generation=0;private destroyed=false;
 constructor(){document.addEventListener('visibilitychange',this.visibility);window.addEventListener('pagehide',this.hide);}
 value(e:Event){return (e.target as HTMLInputElement).value;}
 async start(){this.stopCamera();this.message.set('');const generation=++this.generation;
   try{if(!window.isSecureContext||!navigator.mediaDevices?.getUserMedia)throw new Error();const stream=await navigator.mediaDevices.getUserMedia({audio:false,video:{facingMode:{ideal:'environment'},width:{ideal:1600}}});if(generation!==this.generation||this.destroyed){stream.getTracks().forEach(t=>t.stop());return;}this.stream=stream;this.camera.set(true);this.video.nativeElement.srcObject=stream;await this.video.nativeElement.play();}
   catch{this.stopCamera();this.message.set('Caméra indisponible ou accès refusé. Utilisez une photo locale ou la recherche manuelle. Sur téléphone, un accès HTTPS est nécessaire.');}
 }
 capture(){const video=this.video.nativeElement;if(!video.videoWidth){this.message.set('La caméra démarre encore. Attendez l’aperçu avant de capturer.');return;}const canvas=document.createElement('canvas');const ratio=Math.min(1,1600/video.videoWidth);canvas.width=Math.round(video.videoWidth*ratio);canvas.height=Math.round(video.videoHeight*ratio);canvas.getContext('2d')!.drawImage(video,0,0,canvas.width,canvas.height);this.stopCamera();void this.read(canvas);}
 async upload(e:Event){const input=e.target as HTMLInputElement;const file=input.files?.[0];input.value='';if(!file)return;this.stopCamera();if(file.size>10*1024*1024||!file.type.startsWith('image/')){this.message.set('Choisissez une photo de 10 Mo maximum. Si le format HEIC est refusé, utilisez une photo JPEG ou une capture d’écran.');return;}
   const generation=++this.generation;let bitmap:ImageBitmap|null=null;let image:HTMLImageElement|null=null;let objectUrl='';
   try{try{bitmap=await createImageBitmap(file);}catch{objectUrl=URL.createObjectURL(file);image=new Image();image.src=objectUrl;await image.decode();}const source=bitmap??image!;if(generation!==this.generation||this.destroyed)return;if(source.width*source.height>32_000_000)throw new Error();const ratio=Math.min(1,1600/Math.max(source.width,source.height));const canvas=document.createElement('canvas');canvas.width=Math.round(source.width*ratio);canvas.height=Math.round(source.height*ratio);canvas.getContext('2d')!.drawImage(source,0,0,canvas.width,canvas.height);await this.read(canvas);}catch{this.message.set('Format d’image non lisible sur cet appareil. Essayez une photo JPEG ou une capture d’écran (PNG), puis cadrez les noms.');}finally{bitmap?.close();if(image)image.src='';if(objectUrl)URL.revokeObjectURL(objectUrl);}
 }
 private async read(canvas:HTMLCanvasElement){const generation=++this.generation;this.canvas=canvas;this.busy.set(true);this.message.set('');this.status.set('Chargement du moteur local ; la première lecture peut prendre quelques secondes…');let timer:ReturnType<typeof setTimeout>|undefined;
   try{timer=setTimeout(()=>{if(generation===this.generation){this.cancel();this.message.set('Lecture trop longue. Reprenez une photo plus nette ou recherchez manuellement.');}},90000);const asset=await fetch('/ocr/worker.min.js',{credentials:'same-origin',cache:'no-store',signal:AbortSignal.timeout(10000)});if(generation!==this.generation||this.destroyed)return;if(!asset.ok||!(asset.headers.get('content-type')??'').includes('javascript'))throw new Error('OCR_ASSETS');
     const worker=await createWorker('fra',OEM.LSTM_ONLY,{workerPath:'/ocr/worker.min.js',corePath:'/ocr',langPath:'/ocr',workerBlobURL:false,cacheMethod:'none',logger:m=>{if(generation!==this.generation||this.destroyed)return;const percent=Math.round((m.progress??0)*100);this.status.set(m.status==='recognizing text'?'Lecture des noms… '+percent+' %':'Chargement du moteur local… '+percent+' %');},errorHandler:()=>{}});
     if(generation!==this.generation||this.destroyed){await worker.terminate();return;}this.worker=worker;this.status.set('Lecture sur ce téléphone…');await worker.setParameters({tessedit_pageseg_mode:PSM.SPARSE_TEXT});
     const response=await worker.recognize(canvas,{}, {text:true});if(generation!==this.generation||this.destroyed)return;const names=extractNames(response.data.text);response.data.text='';this.lastName=names.lastName;this.firstName=names.firstName;this.result.set(true);if(!this.lastName||!this.firstName)this.message.set('Le nom ou le prénom n’a pas été identifié. Renseignez les champs ou utilisez la recherche manuelle.');
   }catch(e){if(generation===this.generation&&!this.destroyed)this.message.set(e instanceof Error&&e.message==='OCR_ASSETS'?'Le moteur OCR est indisponible ou la session a expiré. Reconnectez-vous et utilisez la version complète de l’application.':'La lecture locale a échoué. Essayez une photo JPEG plus nette, cadrée sur les noms, ou recherchez manuellement.');}
   finally{clearTimeout(timer);canvas.width=0;canvas.height=0;if(this.canvas===canvas)this.canvas=null;if(generation===this.generation){this.busy.set(false);await this.terminate();}}
 }
 private stopCamera(){this.stream?.getTracks().forEach(t=>t.stop());this.stream=null;this.video?.nativeElement&&(this.video.nativeElement.srcObject=null);this.camera.set(false);}
 private async terminate(){const worker=this.worker;this.worker=null;if(worker)try{await worker.terminate();}catch{}}
 cancel(){if(this.canvas){this.canvas.width=0;this.canvas.height=0;this.canvas=null;}this.generation++;this.busy.set(false);this.stopCamera();void this.terminate();}
 reset(){this.cancel();this.result.set(false);this.lastName='';this.firstName='';this.message.set('');}
 search(e:Event){e.preventDefault();const query=[this.firstName.trim(),this.lastName.trim()].filter(Boolean).join(' ');this.reset();this.names.emit(query);}
 manual(){this.reset();this.dismissed.emit();}
 private visibility=()=>{if(document.hidden)this.cancel();};private hide=()=>this.cancel();
 ngOnDestroy(){this.destroyed=true;this.reset();document.removeEventListener('visibilitychange',this.visibility);window.removeEventListener('pagehide',this.hide);}
}
