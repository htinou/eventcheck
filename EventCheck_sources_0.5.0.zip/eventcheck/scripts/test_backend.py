#!/usr/bin/env python3
from pathlib import Path
import os,subprocess
root=Path(__file__).resolve().parents[1];env=os.environ.copy();env.setdefault('TEST_PROFILE','embedded')
if env['TEST_PROFILE']=='postgres':
 local=root/'.env.local'
 if local.exists():
  for line in local.read_text().splitlines():
   if line.strip() and not line.startswith('#'):
    key,value=line.split('=',1);env.setdefault(key,value)
 env.setdefault('TEST_DB_URL','jdbc:postgresql://localhost:5433/eventcheck_test');env.setdefault('TEST_DB_USER','eventcheck');env.setdefault('TEST_DB_PASSWORD',env.get('DB_PASSWORD',''));env['PG_NATIVE']='true'
 if not env['TEST_DB_PASSWORD']:raise SystemExit('Définissez TEST_DB_PASSWORD pour PostgreSQL.')
 if 'eventcheck_test' not in env['TEST_DB_URL']:raise SystemExit('Utilisez une base dédiée eventcheck_test.')
else:
 env.pop('PG_NATIVE',None)
 for key in ['TEST_DB_URL','TEST_DB_USER','TEST_DB_PASSWORD']:env.pop(key,None)
raise SystemExit(subprocess.call(['mvn','-B','-f',str(root/'backend/pom.xml'),'verify'],env=env))
