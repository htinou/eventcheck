#!/usr/bin/env python3
from pathlib import Path
import os,subprocess
root=Path(__file__).resolve().parents[1]
env=os.environ.copy()
# Local file database is now the default; no .env.local or PostgreSQL required.
env.setdefault('SPRING_PROFILES_ACTIVE','embedded,demo')
if 'embedded' in env['SPRING_PROFILES_ACTIVE'].split(','):
 for name in ['DB_URL','DB_USER','DB_PASSWORD','DEMO_PASSWORD']:env.pop(name,None)
else:
 local=root/'.env.local'
 if local.exists():
  for line in local.read_text().splitlines():
   if line.strip() and not line.startswith('#'):
    key,value=line.split('=',1);env.setdefault(key,value)
 env.setdefault('COOKIE_SECURE','false')
jar=root/'release/eventcheck.jar' 
if not jar.is_file():raise SystemExit('JAR absent : exécutez scripts/build_release.py.')
raise SystemExit(subprocess.call(['java','-jar',str(jar)],env=env,cwd=root))
