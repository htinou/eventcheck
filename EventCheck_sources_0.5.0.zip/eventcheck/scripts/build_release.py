#!/usr/bin/env python3
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parents[1]
subprocess.run(['npm', 'ci', '--no-fund', '--no-audit'], cwd=root/'frontend', check=True)
subprocess.run(['npm', 'run', 'build'], cwd=root/'frontend', check=True)
static = root/'backend/src/main/resources/static'
if static.exists():
    shutil.rmtree(static)
shutil.copytree(root/'frontend/dist/eventcheck/browser', static)
subprocess.run(['mvn', '-B', '-DskipTests', 'clean', 'package', 'spring-boot:repackage'], cwd=root/'backend', check=True)
release=root/'release'
release.mkdir(exist_ok=True)
shutil.copy2(root/'backend/target/eventcheck-api-0.5.0.jar', release/'eventcheck.jar')
print('Application assemblée dans release/eventcheck.jar.')
