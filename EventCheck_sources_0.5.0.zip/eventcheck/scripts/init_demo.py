#!/usr/bin/env python3
from pathlib import Path
import secrets

root = Path(__file__).resolve().parents[1]
target = root / '.env.local'
if target.exists():
    print('.env.local existe déjà ; aucun mot de passe remplacé.')
else:
    target.write_text('DB_PASSWORD=' + secrets.token_urlsafe(24) + '\nDEMO_PASSWORD=' + secrets.token_urlsafe(24) + '\n')
    target.chmod(0o600)
    print('Configuration locale générée dans .env.local. Les mots de passe restent sur cette machine.')
